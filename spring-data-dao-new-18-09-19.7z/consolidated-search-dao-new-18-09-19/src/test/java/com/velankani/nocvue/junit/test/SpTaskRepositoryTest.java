package com.velankani.nocvue.junit.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.Assert;

import com.velankani.nocvue.common.repository.SpTaskRepository;
import com.velankani.nocvue.eagger.useraction.model.SpTask;

@RunWith(MockitoJUnitRunner.class)
public class SpTaskRepositoryTest {

	    @Mock SpTaskRepository repository;	
	    
	    @InjectMocks SpTaskRepository spTaskRepository;
	    
	    @Test
	    public void findBySpJobId() {
	        System.out.println("repository :::"+repository);
	        /*System.out.println("spTaskRepository :::"+spTaskRepository);*/
	    	List<SpTask> searchResults = repository.findBySpJobId(10444L);
	        Assert.notNull(searchResults,"Result list not empyt");
	    }
	    

}
