package com.velankani.nocvue.junit.test.repository.util;

import java.util.ArrayList;
import java.util.List;

import com.velankani.nocvue.common.model.SpEmsDetails;
import com.velankani.nocvue.common.model.SpNode;
import com.velankani.nocvue.common.model.SpProtocolSettings;

public class TestRepositoryUtil {
	public static final int COUNT = 3;
	public static final long ID = 23;
	public static final String EMS_NAME = "EMS name";
	public static final String UPDATED_EMS_NAME = "Modified Ems name";
	public static final String EMS_DESCRIPTION = "Sample description";
	
	public static final String NODE_NAME = "Node name";
	public static final String UPDATED_NODE_NAME = "Modified Node name";
	public static final String DEVICE_TYPE = "Device Type";
	
	public static final String LOCATION = "Chennai";
	
	public static SpNode getNodeEntity(long id, String name, String deviceType, String location) {
		SpNode details = new SpNode();
		details.setId(id);
		details.setName(name);
		details.setDeviceType(deviceType);
		details.setLocation(location);
		
		SpEmsDetails emsDetails = new SpEmsDetails();
		details.setSpEmsDetails(emsDetails);
		
		List<SpProtocolSettings> ps = new ArrayList<SpProtocolSettings>();
		details.setSpProtocolSettings(ps);
		
		return details;
	}
	
	public static List<SpNode> getSpNodeEntity(int count) {
		List<SpNode> emsDetails = new ArrayList<SpNode>();
		for(int i=1; i<= count;i++) {
			emsDetails.add(getNodeEntity(i, "EMS name - "+i, "Device TYpe -"+i, LOCATION));
		}
		return emsDetails;
	}
	
	
	public static SpEmsDetails getEmsDetailsEntity(long id, String name, String description) {
		SpEmsDetails details = new SpEmsDetails();
		details.setId(id);
		details.setName(name);
		details.setDescription(description);
		List<SpProtocolSettings> ps = new ArrayList<SpProtocolSettings>();
		details.setSpProtocolSettings(ps);
		return details;
	}
	
	public static SpEmsDetails getEmsDetailsEntity(long id, String name, String description, String location) {
		SpEmsDetails details = new SpEmsDetails();
		details.setId(id);
		details.setName(name);
		details.setDescription(description);
		details.setLocation(location);
		List<SpProtocolSettings> ps = new ArrayList<SpProtocolSettings>();
		details.setSpProtocolSettings(ps);
		return details;
	}
	
	public static List<SpEmsDetails> getSpEmsDetailsEntity(int count) {
		List<SpEmsDetails> emsDetails = new ArrayList<SpEmsDetails>();
		for(int i=1; i<= count;i++) {
			emsDetails.add(getEmsDetailsEntity(i, "EMS name - "+i, "EMS Description -"+i));
		}
		return emsDetails;
	}
}
