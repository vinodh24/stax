package com.velankani.consolidated.common.dao.service;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;


public class DynamicPropsGeneratingForQuery<T> implements Example<T>{

	private T probe;
	private String startTime;
	private StringBuffer dateMatching;
	private final ExampleMatcher matcher;
	
	public DynamicPropsGeneratingForQuery(T probe, String to_date,ExampleMatcher matcher) {
		super();
		this.probe = probe;
		this.startTime = to_date;
		this.matcher=matcher;
	}
		
	public T getProbe() {
		return probe;
	}
	public String getTo_date() {
		return startTime;
	}
	
	public ExampleMatcher getMatcher() {
		return matcher;
	}
	public void setTo_date(String to_date) {
		this.startTime = to_date;
	}
	
	public StringBuffer getDateMatching() {
		return dateMatching;
	}

	public void setDateMatching(StringBuffer dateMatching) {
		this.dateMatching = dateMatching;
	}

	@Override
	public String toString() {
		System.out.println("key ::: "+probe.equals("startTime"));
		return "TypedExample [probe=" + probe + ", startTime=" + startTime
				+ ", dateMatching=" + dateMatching + ", matcher=" + matcher
				+ "]";
	}
	@SuppressWarnings("unchecked")
	public Class<T> getProbeType() {
		return (Class<T>)SpringLoader.getUserClass(getProbe().getClass());
	}
	

}
