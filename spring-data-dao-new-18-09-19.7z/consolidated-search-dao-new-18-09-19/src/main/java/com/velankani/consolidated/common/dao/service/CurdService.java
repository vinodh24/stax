package com.velankani.consolidated.common.dao.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.velankani.nocvue.common.model.Alarm;
import com.velankani.nocvue.common.model.DeviceDetailsStatusEnum;
import com.velankani.nocvue.common.repository.AlarmRepository;
import com.velankani.nocvue.common.repository.SpEmsDetailsRepositroy;
import com.velankani.nocvue.common.repository.SpJobRepository;
import com.velankani.nocvue.common.repository.SpNodeRepository;
import com.velankani.nocvue.common.repository.SpTaskRepository;
import com.velankani.nocvue.eagger.useraction.model.SpJob;
import com.velankani.nocvue.eagger.useraction.model.SpTask;




public class CurdService {
	
	@Autowired
	private AlarmRepository alarmRepository;
	
	@Autowired
	private SpEmsDetailsRepositroy spEmsDetailsRepository;
	
	@Autowired
	private SpNodeRepository spNodeRepository;
	
	@Autowired
	private SpJobRepository sPJobRepository;
	
	@Autowired
	private SpTaskRepository spTaskRepository;
	
	
	public void getAllEmsDetailsByLastSyncStatus(){
		System.out.println(spEmsDetailsRepository.getAllEmsDetailsByLastSyncStatus(DeviceDetailsStatusEnum.OUT_OF_SYNC));
	}
	
	public void getAllDirectDeviceByLastSyncStatus(){
		System.out.println(spNodeRepository.getAllDirectDeviceByLastSyncStatus(DeviceDetailsStatusEnum.OUT_OF_SYNC));
	}
	
	public void saveAlaram(Alarm alaram,List<Alarm> alarmList){
		/*alarmRepository.save(alaram);*/
		alarmRepository.saveAll(alarmList);
	}
	@Transactional(isolation = Isolation.REPEATABLE_READ)
	public void saveAllAlaram(List<SpJob> SpJobList,List<SpJob> SpJobList1){
		new Thread(()->{
			sPJobRepository.saveAll(SpJobList);
			sPJobRepository.flush();
			System.out.println(" :::new Thread Name "+Thread.currentThread().getName());
			}).start();	
		
		
		/*try {
			Thread.sleep(300L);
			List<SpJob> SpJobList11=sPJobRepository.saveAll(SpJobList1);
			sPJobRepository.flush();
			System.out.println(SpJobList11.size()+" :::Main Thread Name "+Thread.currentThread().getName());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
		List<SpJob> SpJobList11=sPJobRepository.saveAll(SpJobList1);
		System.out.println(SpJobList11);
		sPJobRepository.flush();
		  
	}
	public void findAllById(List<Long> ids){
		System.out.println(alarmRepository.findAllById(ids).size());
	}
	public void findAll(){
		System.out.println(alarmRepository.findAll().size());
	}
	
	public void findById(Long id){
		alarmRepository.findById(id);
	}
	
	public void saveJob(SpJob job){
		sPJobRepository.save(job);
	}
	
	public void findAllSpJob(){
		System.out.println(sPJobRepository.findAll().size());
	}
	
	public void findBySpJobId(Long id){
		
		sPJobRepository.findById(id);
	}
	
	public void updateEmsRegistrationStatus() {
		int i = spEmsDetailsRepository.updateEmsRegistrationStatus(
				DeviceDetailsStatusEnum.OUT_OF_SYNC,new Timestamp(System.currentTimeMillis()), 131L);
		System.out.println("updated status " + i);
	}
	
	public void updateNodeRegistrationStatus() {
		int i = spNodeRepository.updateNodeRegistrationStatus(
				DeviceDetailsStatusEnum.OUT_OF_SYNC,new Timestamp(System.currentTimeMillis()), 831L);
		System.out.println("updated status " + i);
	}
	public void updateNodeRegistrationStatusByNodeId() {
		int i = spNodeRepository.updateEmsRegistrationStatus(
				DeviceDetailsStatusEnum.OUT_OF_SYNC,new Timestamp(System.currentTimeMillis()), 131L);
		System.out.println("updated status " + i);
	}
	
	public void updateAlaramSyncStatusByNodeId() {
		int i = spNodeRepository.updateAlaramSyncStatusByNodeId(DeviceDetailsStatusEnum.OUT_OF_SYNC, 2351L);
		System.out.println("updated status " + i);
	}

	public void updateAlaramSyncStatusByEmsId() {
		int i = spNodeRepository.updateAlaramSyncStatusByEmsId(DeviceDetailsStatusEnum.OUT_OF_SYNC, 131L);
		System.out.println("updated status " + i);
	}
	
	public void updateAlaramSyncStatusById() {
		int i =spEmsDetailsRepository.updateAlaramSyncStatusById(DeviceDetailsStatusEnum.OUT_OF_SYNC, 131L);
		System.out.println("updated status " + i);
	}
	
	/*@Transactional(readOnly = true)
	public void findByUserName(String userName){
		try (Stream<SpJob> stream = sPJobRepository.findByUserName(userName)) {
		System.out.println(stream.collect(Collectors.toList())+" ::::");	
		}
		System.out.println(sPJobRepository.findByUserName(userName));
	}*/
	/*@Transactional()
	public void findByUserName1(String userName){
		System.out.println("findByUserName1:::  "+sPJobRepository.findByUserName1(userName));
	}*/
	
	public void findByFilters(SpJob SpJob,Pageable pageable){
		Page<SpJob> listJobs= sPJobRepository.findAll(Example.of(SpJob,getMatcher()),pageable);
		System.out.println(listJobs.getTotalPages()+"   "+listJobs.getTotalElements());
	}
	
	public ExampleMatcher getMatcher(){
		ExampleMatcher matcher = ExampleMatcher.matchingAll()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
		return matcher;		
	}
	public ExampleMatcher getMatcherddd(){
		ExampleMatcher matcher = ExampleMatcher.matchingAll()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
		return matcher;		
	}
	
	public ExampleMatcher getDateMatcher() {
		ExampleMatcher matcher =ExampleMatcher.matching()
                .withMatcher("to_date()", match -> match.contains())
                .withIgnoreNullValues();
		return matcher;
	}
	
	public void searchFilters(){
		SpJob SpJob=new SpJob();
	    SpJob.setUserName("n");
	    SpJob.setJobId("");
		ExampleMatcher matcher = ExampleMatcher.matchingAll()
				/*.withMatcher("id", ExampleMatcher.GenericPropertyMatcher.of(ExampleMatcher.StringMatcher.CONTAINING))*/
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
			    .withIgnorePaths("id")
			    .withIgnorePaths("taskCount").withIgnorePaths("completedTasks")
			    .withIgnorePaths("successTasks") .withIgnorePaths("failureTasks");
			    /*.withMatcher("score", exact());*/
		List<SpJob> listJobs=sPJobRepository.findAll(Example.of(SpJob,matcher));
		System.out.println(listJobs.size());
	}
	public void findByFilters1(){
		Pageable pageable = PageRequest.of(5, 3);
		SpJob SpJob=new SpJob();
	    SpJob.setUserName("n");
	    SpJob.setJobId("");
	    SpJob.setOutputFilePath("");
		ExampleMatcher matcher = ExampleMatcher.matchingAll()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
		Page<SpJob> listJobs= sPJobRepository.findAll(Example.of(SpJob,matcher),pageable);
		System.out.println(listJobs.getTotalPages()+"   "+listJobs.getTotalElements());
	}

	public void findByFilters(SpTask spTask, Pageable pageable) {
		Page<SpTask> listJobs= spTaskRepository.findAll(Example.of(spTask,getMatcher()),pageable);
		System.out.println(listJobs.getTotalPages()+","+listJobs.getTotalElements()+"::: "+listJobs.getContent());		
	}
	public void findByFiltersByDate(SpTask spTask) {
		List<SpTask> listJobs= spTaskRepository.findAll(Example.of(spTask,getDateMatcher()));
		System.out.println("::: "+listJobs);		
	}
	
	public void findByFilters4555(SpJob SpJob,Pageable pageable){
		TypedExample<SpJob> a =new TypedExample<SpJob>(SpJob, "444", getMatcher());
		System.out.println("a  "+a);
		System.out.println("fdffffff"+Example.of(SpJob,getMatcher()));
		/*Page<SpJob> listJobs= sPJobRepository.findAll(a,pageable);*/
		/*System.out.println(listJobs.getTotalPages()+"   "+listJobs.getTotalElements());*/
	}
	public void findByFilters45ddd55(SpJob SpJob,Pageable pageable){
		DynamicPropsGeneratingForQuery<SpJob> a =new DynamicPropsGeneratingForQuery<SpJob>(SpJob, "30-09-19", getMatcher());
		System.out.println("a  "+a);
		Page<SpJob> listJobs= sPJobRepository.findAll(a,pageable);
		System.out.println(listJobs.getTotalPages()+"   "+listJobs.getTotalElements());
	}


}
