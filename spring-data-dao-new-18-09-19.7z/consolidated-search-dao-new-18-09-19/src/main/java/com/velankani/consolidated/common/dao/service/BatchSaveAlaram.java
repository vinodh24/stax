package com.velankani.consolidated.common.dao.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.velankani.nocvue.common.model.Alarm;

public class BatchSaveAlaram {
	
	public static void main(String[] args) throws InterruptedException {
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springConfig.xml");
		CurdService curdOperation = (CurdService) context.getBean("curdRepository");
		System.out.println(curdOperation + "    ::::;curdOperation");
		
		//loop(curdOperation);
		BatchSaveAlaram batchSaveAlaram=new BatchSaveAlaram();
		loop(curdOperation);
	}
	
	private List<Alarm> list = new LinkedList<Alarm>();
	private LocalDateTime ldt =LocalDateTime.now();
	private LocalDateTime gdt =LocalDateTime.now();
	private void pushToDB(Alarm alarm, CurdService curdOperation) throws InterruptedException {
		if (this.list.size() >= 1000 || ldt.isAfter(gdt)) {
			List<Alarm> toStore = new LinkedList<Alarm>();
			toStore.addAll(list);			
			list = null;
			list = new LinkedList<Alarm>();
			System.out.println(" size of inside elements::::   "+toStore.size());
		} else {
			list.add(alarm);
			if(this.list.size()==1){
				gdt=ldt.plusMinutes(1);	
				System.out.println(ldt +" ::::  "+gdt);
			}
			if(this.list.size()==500){
				System.out.println("waiting before");
				Thread.sleep(60000);
				System.out.println("waiting after");

			}
		}
			
	}
	
	public static void loop(CurdService curdOperation) throws InterruptedException{
		BatchSaveAlaram batchSaveAlaram=new BatchSaveAlaram();
		for(int i=0;i<10000;i++){
			batchSaveAlaram.pushToDB(getAlarm(i),curdOperation);
		}
	}
	/*private Timer t = new Timer();  
	public  void executeEveryMinut() {
		
		TimerTask tt = new TimerTask() {  
		    @Override  
		    public void run() {  
		      System.out.println(" ddddd"+LocalTime.now());
		    };  
		}; 
		
		t.scheduleAtFixedRate(tt,60,100000);    
	}*/
	
	/*public static void executeEveryMinut(){
		Timer timer = new Timer();
		timer.schedule( new TimerTask() {

			public void run() {
				
			}
		   
		 }, 0, 60*1000);
	}*/
	
	
	/*
	public static void listImplementaion(Alarm alarm,CurdService curdOperation){
		boolean flag=false;
		List<Alarm> task1 = Arrays.asList(new Alarm[1000]);
		List<Alarm> task2 = Arrays.asList(new Alarm[1000]);
		
		if (task1.size() != 1000 && task2.isEmpty()) {
			task1.add(alarm);
			curdOperation.saveAlaram(null, task1);
			flag = true;
		} else {
			task1 = null;
		}
		if (flag == true && task2.size() != 1000) {
			task1.add(alarm);
			
			flag = true;
		}
		
		if(task1.size()==1000 || task2.size()==1000){
			curdOperation.saveAlaram(null, task1);
		}
		
	}*/
	
	public static Alarm getAlarm(int i){
		Alarm alarm=new Alarm();
		//alarm.setAcknowledged("knowle");
		alarm.setAdditionalText("AdditionalTex");
		alarm.setAlarmSourceId("AlarmSourceId");
		alarm.setAlertIdentifier("AlertIdentifier"+i);
		alarm.setCategory("Category");
		alarm.setCreateTime(new Timestamp(System.currentTimeMillis()));
		alarm.setDescription("Description");
		//alarm.setEmsDetailsId(i);
		alarm.setFailureObject("FailureObject");
		alarm.setFailureObjectDescription("FailureObjectDescription");
		alarm.setGeneratedSource("GeneratedSource");
		alarm.setModifiedTime(new Timestamp(System.currentTimeMillis()));
		alarm.setNodeName("NodeName");
	//	alarm.setOccuranceCount(2L);
		alarm.setOwner("Owner");
		alarm.setPreviousSeverity(5L);
		alarm.setProbableCause("ProbableCause");
		alarm.setSequenceNumber("SequenceNumber");
		//alarm.setServiceAffecting(5L);
		alarm.setSeverity(10L);	
		return alarm;		
	}
	
}
