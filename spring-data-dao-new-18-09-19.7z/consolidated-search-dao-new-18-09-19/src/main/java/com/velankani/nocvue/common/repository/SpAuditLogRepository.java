package com.velankani.nocvue.common.repository;

import com.velankani.nocvue.common.model.SpAuditLog;


public interface SpAuditLogRepository extends GenericDAO<SpAuditLog>{

	
	
}
