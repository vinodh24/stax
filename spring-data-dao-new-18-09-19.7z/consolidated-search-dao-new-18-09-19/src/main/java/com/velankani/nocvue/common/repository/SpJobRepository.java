package com.velankani.nocvue.common.repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.velankani.nocvue.eagger.useraction.model.SpJob;
import com.velankani.nocvue.eagger.useraction.model.SpJobEnum;

public interface SpJobRepository extends GenericDAO<SpJob> {

	@Query @Transactional @Modifying	
	int updateJobStatusAndRemarks(SpJobEnum setJobStatus, String setRemarks,SpJobEnum jobStatus);
	
	@Query @Transactional @Modifying	
	int updateJobStatus(SpJobEnum setJobStatus,SpJobEnum jobStatus);
	
	@Query @Transactional @Modifying	
	int updateRemarks(String setRemarks,SpJobEnum jobStatus);
	
	@Query @Transactional @Modifying
	int updateSpJobStatusAndResponseTime(SpJobEnum jobStatus,Timestamp endTime,long successCount, long failureCount, String jobId);
	
	@Query(value="select * from sp_job e where e.starttime like %?1% and e.endtime like %?2%", nativeQuery = true)
	List<SpJob> findByTimeAndUser(String startDate , String  endDate, String username);
	
	@Query(value="select * from sp_job e where e.starttime like %?1%", nativeQuery = true)
	List<SpJob> findOneDayRecordByUser(String starttime, String username);
	
	@Query
	List<SpJob> findByUserNameAndDateRange(String userName, String startDate, String endDate);
	
	@Query
	List<SpJob> findByUserNameAndOneDayRange(String userName, String startDate);
		
	@Query
	List<SpJob> findByAdminUserAndDateRange(String startDate, String endDate);
	
	@Query
	List<SpJob> findByAdminUserAndOneDayRange(String startDate);
	
	 /*@Query
	 List<SpJob> findByUserName1(String userName,Pageable pageable);*/
	
	/* @Query
	 Stream<SpJob> findByUserName1(String userName);*/
	
	 
	/* Stream<SpJob>findByUserName(String userName);*/
	
	
	@Query
	public List<SpJob> findAll();
	
	@Override
	public Optional<SpJob> findById(Long id);
}
