package com.velankani.nocvue.common.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="SP_EMS_DETAILS")
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class, property="id")
public class SpEmsDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_sp_ems_details")
	@SequenceGenerator(name = "seq_gen_sp_ems_details", sequenceName = "SEQ_SP_EMS_DETAILS",allocationSize = 1, initialValue = 1)
	private long id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "src_ref_id")
	private String srcRefId;
	
	@Column(name = "ipaddress")
	private String ipAddress;
	
	@Column(name = "lastsyncstatus")
	@Enumerated(EnumType.STRING)
	private DeviceDetailsStatusEnum lastSyncStatus;
	
	@Column(name = "alarmsyncstatus")
	@Enumerated(EnumType.STRING)
	private DeviceDetailsStatusEnum alarmSyncStatus;
	
	@Column(name = "inventorysyncstatus")
	@Enumerated(EnumType.STRING)
	private DeviceDetailsStatusEnum inventorySyncStatus;
	
	@Column(name = "lastsynctime")
	private Date lastSyncTime;
	
	@Column(name = "location")
	private String location;
	
	@Column(name = "state")
	private String state;
	
	@Column(name = "vendor")
	private String vendor;
	
	@Column(name = "version")
	private String version;
	
	@Column(name = "addlparams")
	private String addlParams;
	
	@Column(name = "description")
	private String description;
	
	@OneToMany(mappedBy="spEmsDetails", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval=true)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private List<SpNode> spNodes;
	
	@OneToMany(mappedBy="spEmsDetails", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval=true)
	private List<SpProtocolSettings> spProtocolSettings;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSrcRefId() {
		return srcRefId;
	}

	public void setSrcRefId(String srcRefId) {
		this.srcRefId = srcRefId;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public DeviceDetailsStatusEnum getLastSyncStatus() {
		return lastSyncStatus;
	}

	public void setLastSyncStatus(DeviceDetailsStatusEnum lastSyncStatus) {
		this.lastSyncStatus = lastSyncStatus;
	}

	public Date getLastSyncTime() {
		return lastSyncTime;
	}

	public void setLastSyncTime(Date lastSyncTime) {
		this.lastSyncTime = lastSyncTime;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAddlParams() {
		return addlParams;
	}

	public void setAddlParams(String addlParams) {
		this.addlParams = addlParams;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@JsonIgnore
	public List<SpNode> getSpNodes() {
		return spNodes;
	}

	public void setSpNodes(List<SpNode> spNodes) {
		this.spNodes = spNodes;
	}

	public List<SpProtocolSettings> getSpProtocolSettings() {
		return spProtocolSettings;
	}

	public void setSpProtocolSettings(List<SpProtocolSettings> spProtocolSettings) {
		this.spProtocolSettings = spProtocolSettings;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((addlParams == null) ? 0 : addlParams.hashCode());
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result
				+ ((ipAddress == null) ? 0 : ipAddress.hashCode());
		result = prime * result
				+ ((lastSyncStatus == null) ? 0 : lastSyncStatus.hashCode());
		result = prime * result
				+ ((lastSyncTime == null) ? 0 : lastSyncTime.hashCode());
		result = prime * result
				+ ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((spNodes == null) ? 0 : spNodes.hashCode());
		result = prime
				* result
				+ ((spProtocolSettings == null) ? 0 : spProtocolSettings
						.hashCode());
		result = prime * result
				+ ((srcRefId == null) ? 0 : srcRefId.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((vendor == null) ? 0 : vendor.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SpEmsDetails other = (SpEmsDetails) obj;
		if (addlParams == null) {
			if (other.addlParams != null)
				return false;
		} else if (!addlParams.equals(other.addlParams))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (id != other.id)
			return false;
		if (ipAddress == null) {
			if (other.ipAddress != null)
				return false;
		} else if (!ipAddress.equals(other.ipAddress))
			return false;
		if (lastSyncStatus != other.lastSyncStatus)
			return false;
		if (lastSyncTime == null) {
			if (other.lastSyncTime != null)
				return false;
		} else if (!lastSyncTime.equals(other.lastSyncTime))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (spNodes == null) {
			if (other.spNodes != null)
				return false;
		} else if (!spNodes.equals(other.spNodes))
			return false;
		if (spProtocolSettings == null) {
			if (other.spProtocolSettings != null)
				return false;
		} else if (!spProtocolSettings.equals(other.spProtocolSettings))
			return false;
		if (srcRefId == null) {
			if (other.srcRefId != null)
				return false;
		} else if (!srcRefId.equals(other.srcRefId))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (vendor == null) {
			if (other.vendor != null)
				return false;
		} else if (!vendor.equals(other.vendor))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}

	
}
	