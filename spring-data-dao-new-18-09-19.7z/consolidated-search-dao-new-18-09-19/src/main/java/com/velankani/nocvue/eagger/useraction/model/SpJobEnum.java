package com.velankani.nocvue.eagger.useraction.model;

public enum SpJobEnum {
	FAILED, COMPLETED, IN_PROGRESS;
}
