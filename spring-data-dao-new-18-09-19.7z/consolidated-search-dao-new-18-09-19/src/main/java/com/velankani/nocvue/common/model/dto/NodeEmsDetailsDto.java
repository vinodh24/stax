package com.velankani.nocvue.common.model.dto;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;

import com.velankani.nocvue.common.model.DeviceDetailsStatusEnum;

@AllArgsConstructor
@RequiredArgsConstructor
public class NodeEmsDetailsDto {
	
	private String emsIp;
	private String nodeIp;
	private String emsId;
	private Long emsDbId;
	private String emsName;
	private String vendor;
	private String userName;
	private String password;
	private String startPort;
	private DeviceDetailsStatusEnum lastSyncStatus;
	private String endPort;
	private Long nodeDbId;
	private String clli;
	private String deviceType;
	private String nodeName;
	private boolean isDirectManaged;
	
	
	public NodeEmsDetailsDto( String nodeIp,String deviceType,
			Long nodeDbId, String clli,boolean isDirectManaged,
			String nodeName,String emsIp,Long emsDbId,String emsName, String vendor,
			DeviceDetailsStatusEnum lastSyncStatus, String userName,
			String password, String startPort,String endPort) {
		super();
		this.emsIp = emsIp;
		this.nodeIp = nodeIp;
		this.emsDbId = emsDbId;
		this.emsName = emsName;
		this.vendor = vendor;
		this.userName = userName;
		this.password = password;
		this.startPort = startPort;
		this.lastSyncStatus = lastSyncStatus;
		this.endPort = endPort;
		this.nodeDbId = nodeDbId;
		this.clli = clli;
		this.deviceType = deviceType;
		this.nodeName = nodeName;
		this.isDirectManaged = isDirectManaged;
	}	
	
    
	public NodeEmsDetailsDto(String nodeIp,String deviceType,
			Long nodeDbId, String clli,boolean isDirectManaged,
			String nodeName,DeviceDetailsStatusEnum lastSyncStatus, 
			String userName,String password, String startPort,String endPort) {
		super();
		this.nodeIp = nodeIp;
		this.userName = userName;
		this.password = password;
		this.startPort = startPort;
		this.lastSyncStatus = lastSyncStatus;
		this.endPort = endPort;
		this.nodeDbId = nodeDbId;
		this.clli = clli;
		this.deviceType = deviceType;
		this.nodeName = nodeName;
		this.isDirectManaged = isDirectManaged;
	}	

    public NodeEmsDetailsDto(String emsIp,Long emsDbId,String vendor,String emsName,
			DeviceDetailsStatusEnum lastSyncStatus, String userName,
			String password, String startPort,String endPort) {
		super();
		this.emsIp = emsIp;
		this.emsDbId = emsDbId;
		this.emsName = emsName;
		this.vendor = vendor;
		this.userName = userName;
		this.password = password;
		this.startPort = startPort;
		this.lastSyncStatus = lastSyncStatus;
		this.endPort = endPort;
	}

	public String getEmsIp() {
		return emsIp;
	}


	public void setEmsIp(String emsIp) {
		this.emsIp = emsIp;
	}


	public String getNodeIp() {
		return nodeIp;
	}


	public void setNodeIp(String nodeIp) {
		this.nodeIp = nodeIp;
	}


	public String getEmsId() {
		return emsId;
	}


	public void setEmsId(String emsId) {
		this.emsId = emsId;
	}


	public Long getEmsDbId() {
		return emsDbId;
	}


	public void setEmsDbId(Long emsDbId) {
		this.emsDbId = emsDbId;
	}


	public String getEmsName() {
		return emsName;
	}


	public void setEmsName(String emsName) {
		this.emsName = emsName;
	}


	public String getVendor() {
		return vendor;
	}


	public void setVendor(String vendor) {
		this.vendor = vendor;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getStartPort() {
		return startPort;
	}


	public void setStartPort(String startPort) {
		this.startPort = startPort;
	}


	public DeviceDetailsStatusEnum getLastSyncStatus() {
		return lastSyncStatus;
	}


	public void setLastSyncStatus(DeviceDetailsStatusEnum lastSyncStatus) {
		this.lastSyncStatus = lastSyncStatus;
	}


	public String getEndPort() {
		return endPort;
	}


	public void setEndPort(String endPort) {
		this.endPort = endPort;
	}


	public Long getNodeDbId() {
		return nodeDbId;
	}


	public void setNodeDbId(Long nodeDbId) {
		this.nodeDbId = nodeDbId;
	}


	public String getClli() {
		return clli;
	}


	public void setClli(String clli) {
		this.clli = clli;
	}


	public String getDeviceType() {
		return deviceType;
	}


	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}


	public String getNodeName() {
		return nodeName;
	}


	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public boolean isDirectManaged() {
		return isDirectManaged;
	}


	public void setDirectManaged(boolean isDirectManaged) {
		this.isDirectManaged = isDirectManaged;
	}


	@Override
	public String toString() {
		return "NodeEmsDetailsDto [emsIp=" + emsIp + ", nodeIp=" + nodeIp + ", emsId=" + emsId + ", emsDbId=" + emsDbId
				+ ", emsName=" + emsName + ", vendor=" + vendor + ", userName=" + userName + ", password=" + password
				+ ", startPort=" + startPort + ", lastSyncStatus=" + lastSyncStatus + ", endPort=" + endPort
				+ ", nodeDbId=" + nodeDbId + ", clli=" + clli + ", deviceType=" + deviceType + ", nodeName=" + nodeName
				+ ", isDirectManaged=" + isDirectManaged + "]";
	}
			
}
