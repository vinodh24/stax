package com.velankani.nocvue.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.velankani.nocvue.common.model.FailOverEntry;


public interface FailoverEntryRepository extends GenericDAO<FailOverEntry>{
	
	 @Query("SELECT failover FROM FailOverEntry failover where failover.serverType = ?1 AND failover.ipAddress = ?2")
	 public List<FailOverEntry> findByServerTypeAndIpAddress(@Param("serverType") String serverType, @Param("ipAddress") String ipAddress);
	 
	 
	 @Query("SELECT failover FROM FailOverEntry failover where failover.deviceId IS NOT NULL AND failover.serverType = ?1 AND failover.serverMode = ?2")
	 public List<FailOverEntry> findByServerTypeAndServerMode(@Param("serverType") String serverType, @Param("serverMode") String serverMode);

	 
	 @Query("SELECT failover FROM FailOverEntry failover where failover.serverType = ?1 AND failover.serverName = ?2 AND failover.ipAddress = ?3")
	 public List<FailOverEntry> findByServerTypeAndServerNameAndIpAddress(@Param("serverType") String serverType, @Param("serverName") String serverName, @Param("ipAddress") String ipAddress);
	 
	 @Query("SELECT failover FROM FailOverEntry failover where failover.serverType = ?1 AND failover.serverName = ?2 AND failover.serverMode = ?3")
	 public List<FailOverEntry> findByServerTypeAndServerNameAndServerMode(@Param("serverType") String serverType, @Param("serverName") String serverName, @Param("serverMode") String serverMode);

	 @Query("SELECT failover FROM FailOverEntry failover where failover.serverType = ?1")
	 public List<FailOverEntry> getAllMAS(@Param("serverType") String serverType);

	 @Query("SELECT failover FROM FailOverEntry failover where failover.serverType = ?1 AND failover.deviceId = ?2")
	 public List<FailOverEntry> getAllNSE(@Param("serverType") String serverType, @Param("deviceId") String deviceID);

	 @Query("SELECT failover FROM FailOverEntry failover where failover.serverType = ?1")
	 public List<FailOverEntry> getAllNSE(@Param("serverType") String serverType);

	 
}
