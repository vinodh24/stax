package com.velankani.nocvue.common.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "devicensemapping")
public class DeviceNseEntry {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_device_nse_mapping")
	@SequenceGenerator(name = "seq_gen_device_nse_mapping", sequenceName = "seq_device_nse_mapping",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private long id;
	
	@Column(name = "DEVICEID")
	private String deviceID;
	
	@Column(name = "NSEID")
	private String nseID;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDeviceID() {
		return deviceID;
	}

	public void setDeviceID(String deviceID) {
		this.deviceID = deviceID;
	}

	public String getNseID() {
		return nseID;
	}

	public void setNseID(String nseID) {
		this.nseID = nseID;
	}
	
	public String toString()
	{
		String s = "";
		if(deviceID != null)
			s += deviceID;
		if(nseID != null)
			s += "\t "+nseID;
		return s;
	}
}
