package com.velankani.nocvue.common.repository;

import com.velankani.nocvue.common.model.SpSettings;

public interface SpSettingsRepository  extends GenericDAO<SpSettings>{

}
