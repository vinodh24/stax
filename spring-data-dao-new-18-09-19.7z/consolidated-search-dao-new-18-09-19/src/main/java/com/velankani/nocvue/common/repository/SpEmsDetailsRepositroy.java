package com.velankani.nocvue.common.repository;

import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.velankani.nocvue.common.model.DeviceDetailsStatusEnum;
import com.velankani.nocvue.common.model.SpEmsDetails;
import com.velankani.nocvue.common.model.dto.NodeEmsDetailsDto;

public interface SpEmsDetailsRepositroy extends GenericDAO<SpEmsDetails> {
	
	@Query@Modifying@Transactional
	int updateLastSyncStatus(DeviceDetailsStatusEnum outOfSync, DeviceDetailsStatusEnum inSync);
	
	public List<SpEmsDetails> findByLastSyncStatus(DeviceDetailsStatusEnum lastsyncstatus);
	
	@Query
	public List<NodeEmsDetailsDto> findDeviceDetailsByIpAddress(String ipAddress);
	
	@Query
	public List<NodeEmsDetailsDto> getAllEmsDetails();
	
	@Query
	public SpEmsDetails getEmsDetailsByNameAndLocation(@Param("name") String name, @Param("location") String location);
	
	@Query
	public void deleteEmsDetailsById(@Param("id") long id);
	
	@Query
	public List<NodeEmsDetailsDto> getAllEmsDetailsByLastSyncStatus(DeviceDetailsStatusEnum lastsyncstatus);

	@Query@Modifying@Transactional
	public int updateEmsRegistrationStatus(DeviceDetailsStatusEnum lastsyncstatus,Timestamp timestamp,Long id);
	
	@Query@Modifying@Transactional
	public int updateAlaramSyncStatusById(DeviceDetailsStatusEnum alarmSyncStatus,Long id);
}
