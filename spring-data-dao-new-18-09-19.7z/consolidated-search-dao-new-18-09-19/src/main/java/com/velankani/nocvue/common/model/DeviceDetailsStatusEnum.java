package com.velankani.nocvue.common.model;

public enum DeviceDetailsStatusEnum {
	IN_SYNC, OUT_OF_SYNC, FORCED_STOP;
}
