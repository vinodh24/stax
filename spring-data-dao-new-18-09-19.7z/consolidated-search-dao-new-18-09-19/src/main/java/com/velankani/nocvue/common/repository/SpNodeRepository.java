package com.velankani.nocvue.common.repository;

import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.velankani.nocvue.common.model.DeviceDetailsStatusEnum;
import com.velankani.nocvue.common.model.SpNode;
import com.velankani.nocvue.common.model.dto.NodeEmsDetailsDto;

public interface SpNodeRepository extends GenericDAO<SpNode> {

    @Query
    public List<NodeEmsDetailsDto> findByIpAddress1(String ipAddress);
    
    @Query @Transactional @Modifying
    int updateLastSyncStatus(DeviceDetailsStatusEnum outOfSync,DeviceDetailsStatusEnum forcedStop);

    @Query
    public List<SpNode> findByLastSyncStatus(DeviceDetailsStatusEnum lastsyncstatus);
    
    @Query
    public List<NodeEmsDetailsDto> findDirectDeviceByIpAddress(String ipAddress);
    								
    @Query
    public List<NodeEmsDetailsDto> getAllDirectDevice();
    
	@Query
	List<NodeEmsDetailsDto> findAllDirectDevices(String ipAddress);
	
	@Query
	public void deleteNodeDetailsById(@Param("id") long id);
	
	@Query
	public List<NodeEmsDetailsDto> getAllDirectDeviceByLastSyncStatus(DeviceDetailsStatusEnum lastsyncstatus);

	@Query @Transactional @Modifying
	public int updateNodeRegistrationStatus(DeviceDetailsStatusEnum lastsyncstatus,Timestamp timestamp, long nodeId);
	
	@Query@Modifying@Transactional
	public int updateEmsRegistrationStatus(DeviceDetailsStatusEnum lastsyncstatus,Timestamp timestamp,Long emsId);
	
	@Query@Modifying@Transactional
	public int updateAlaramSyncStatusByNodeId(DeviceDetailsStatusEnum alarmSyncStatus,Long nodeId);
	
	@Query@Modifying@Transactional
	public int updateAlaramSyncStatusByEmsId(DeviceDetailsStatusEnum alarmSyncStatus,Long emsId);
	
}
