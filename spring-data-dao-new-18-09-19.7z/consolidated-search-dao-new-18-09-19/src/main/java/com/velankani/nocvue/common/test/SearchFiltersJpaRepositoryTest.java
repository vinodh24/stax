package com.velankani.nocvue.common.test;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.velankani.consolidated.common.dao.service.CurdService;
import com.velankani.nocvue.eagger.useraction.model.SpJob;
import com.velankani.nocvue.eagger.useraction.model.SpTask;

public class SearchFiltersJpaRepositoryTest {
	public static void main(String[] args) throws ParseException {
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springConfig.xml");
		CurdService curdOperation = (CurdService) context.getBean("curdRepository");
		System.out.println(curdOperation + "    ::::;curdOperation");
		
		/*findByFilters4555(curdOperation);*/
		findBySpTaks(curdOperation);
		
	}
	private static void findByFilters4555(CurdService curdOperation) throws ParseException {
		Pageable pageable = PageRequest.of(5, 3);
		SpJob SpJob=new SpJob();
	    SpJob.setUserName("n");
	    SpJob.setJobId("");
	    SpJob.setOutputFilePath("");
        curdOperation.findByFilters45ddd55(SpJob,pageable);		
	}
	public static void findByfilters(CurdService curdOperation){
		Pageable pageable = PageRequest.of(5, 3);
		SpJob SpJob=new SpJob();
	    SpJob.setUserName("n");
	    SpJob.setJobId("");
	    SpJob.setOutputFilePath("");
	  /*  SpJob.setStartTime(Timestamp.valueOf("2019-09-24 10:52:38.768"));*/
	    curdOperation.findByFilters(SpJob,pageable);
	}
	public static void findBySpTaks(CurdService curdOperation) throws ParseException{
		Pageable pageable = PageRequest.of(1, 2);
		SpTask spTask=new SpTask();
/*		spTask.setTaskStatus(SpJobEnum.FAILED);
		spTask.setDeviceName("");
		spTask.setJobId("");
		spTask.setOutputFilePath("");*/
		spTask.setStartTime(getLocalDate());
		//spTask.setStartTime(getDate());
	    curdOperation.findByFilters(spTask,pageable);
	}

	private static LocalDate getLocalDate() {
		String date = "2019-09-24";
		LocalDate localDate = LocalDate.parse(date);
		System.out.println(localDate);
		return localDate;
	}
	public static Timestamp getTimeStamp() throws ParseException{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = dateFormat.parse("2019-09-24");
		long time = date.getTime();
		return new Timestamp(time);
	}
	public static Date getDate() throws ParseException{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = dateFormat.parse("2019-09-24");
		Date start = new Date(date.getTime());
		System.out.println("date:::"+date);
		return start;
	}
	public static void findBySpTaksDate(CurdService curdOperation) throws ParseException{
	/*	Pageable pageable = PageRequest.of(1, 2);*/
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SpTask spTask=new SpTask();
		//spTask.setStartTime(dateFormat.parse("2019-09-24"));
		System.out.println(spTask.getStartTime());
	    curdOperation.findByFiltersByDate(spTask);
	}
}
