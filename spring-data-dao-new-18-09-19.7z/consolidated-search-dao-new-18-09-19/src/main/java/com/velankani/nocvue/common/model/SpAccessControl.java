package com.velankani.nocvue.common.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "sp_access_control")
public class SpAccessControl {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_sp_access_control")
	@SequenceGenerator(name = "seq_sp_access_control", sequenceName = "SEQ_SP_ACCESS_CONTROL",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private long id;
	
	@Column(name = "groupname")
	private String groupName;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "privileges")
	private String privileges;
	
	@Column(name = "additionalfilters")
	private String additionalFilters;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPrivileges() {
		return privileges;
	}

	public void setPrivileges(String privileges) {
		this.privileges = privileges;
	}

	public String getAdditionalFilters() {
		return additionalFilters;
	}

	public void setAdditionalFilters(String additionalFilters) {
		this.additionalFilters = additionalFilters;
	}

}
