package com.velankani.nocvue.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.velankani.nocvue.common.model.DeviceNseEntry;


public interface DeviceNseEntryRepository extends GenericDAO<DeviceNseEntry>{
	@Query("SELECT dne FROM DeviceNseEntry dne where dne.nseID = ?1")
	 public List<DeviceNseEntry> findByNSEID(@Param("nseID") String nseID);

}
