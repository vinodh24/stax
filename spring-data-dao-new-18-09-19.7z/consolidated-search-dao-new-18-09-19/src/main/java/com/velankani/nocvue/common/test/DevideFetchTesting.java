package com.velankani.nocvue.common.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.velankani.consolidated.common.dao.service.CurdService;

public class DevideFetchTesting {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springConfig.xml");
		CurdService curdOperation = (CurdService) context.getBean("curdRepository");
		System.out.println(curdOperation + "    ::::;curdOperation");
		
		/*curdOperation.getAllEmsDetailsByLastSyncStatus();*/
		
		/*curdOperation.getAllDirectDeviceByLastSyncStatus();*/
		
		/*curdOperation.updateEmsRegistrationStatus();*/
		
		/*curdOperation.updateNodeRegistrationStatus();*/
        
		/*curdOperation.updateNodeRegistrationStatusByNodeId();*/
		
		/*curdOperation.updateAlaramSyncStatusByNodeId();*/
		
		/*curdOperation.updateAlaramSyncStatusByEmsId();*/
		
		curdOperation.updateAlaramSyncStatusById();
	}

}
