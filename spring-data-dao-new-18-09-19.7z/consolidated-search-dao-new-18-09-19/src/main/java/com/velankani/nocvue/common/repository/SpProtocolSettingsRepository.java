package com.velankani.nocvue.common.repository;

import com.velankani.nocvue.common.model.SpProtocolSettings;

public interface SpProtocolSettingsRepository extends GenericDAO<SpProtocolSettings> {
}
