package com.velankani.nocvue.common.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


/**
 * The persistent class for the SP_NODE database table.
 * 
 */

@Entity
@Table(name="SP_NODE")
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class, property="id")
public class SpNode implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_sp_node")
	@SequenceGenerator(name = "seq_gen_sp_node", sequenceName = "SEQ_SP_NODE",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private long id;
	
	@Column(name = "cleicode")
	private String cleiCode;
	
	@Column(name = "clli")
	private String clli;
	
	@Column(name = "devicetype")
	private String  deviceType;
	
	@Column(name = "name")
	private String  name;
	
	@Column(name = "ipaddress1")
	private String ipAddress1;
	
	@Column(name = "ipaddress2")
	private String  ipAddress2;
	
	@Column(name = "updatedtime")
	private Date updatedTime;
	
	@Column(name = "referenceid")
	private String  referenceId;
	
	@Column(name = "addlparams")
	private String  addlParams;
	
	@Column(name = "lastsyncstatus")
	@Enumerated(EnumType.STRING)
	private DeviceDetailsStatusEnum lastSyncStatus;
	
	@Column(name = "alarmsyncstatus")
	@Enumerated(EnumType.STRING)
	private DeviceDetailsStatusEnum alarmSyncStatus;
	
	@Column(name = "inventorysyncstatus")
	@Enumerated(EnumType.STRING)
	private DeviceDetailsStatusEnum inventorySyncStatus;
	
	@Column(name = "lastsynctime")
	private Date lastSyncTime;
	
	@Column(name = "notificationenabled")
	private String  notificationEnabled;
	
	@Column(name = "location")
	private String  location;
	
	@Column(name = "state")
	private String  state;
	
	@Column(name = "isdirectmanaged")
	private boolean isDirectManaged;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="EMSID", referencedColumnName = "id")
	private SpEmsDetails spEmsDetails;
	
	@OneToMany(mappedBy="spNode", cascade=CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval=true)
	private List<SpProtocolSettings> spProtocolSettings;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCleiCode() {
		return cleiCode;
	}

	public void setCleiCode(String cleiCode) {
		this.cleiCode = cleiCode;
	}

	public String getClli() {
		return clli;
	}

	public void setClli(String clli) {
		this.clli = clli;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIpAddress1() {
		return ipAddress1;
	}

	public void setIpAddress1(String ipAddress1) {
		this.ipAddress1 = ipAddress1;
	}

	public String getIpAddress2() {
		return ipAddress2;
	}

	public void setIpAddress2(String ipAddress2) {
		this.ipAddress2 = ipAddress2;
	}

	public Date getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getAddlParams() {
		return addlParams;
	}

	public void setAddlParams(String addlParams) {
		this.addlParams = addlParams;
	}

	public DeviceDetailsStatusEnum getLastSyncStatus() {
		return lastSyncStatus;
	}

	public void setLastSyncStatus(DeviceDetailsStatusEnum lastSyncStatus) {
		this.lastSyncStatus = lastSyncStatus;
	}

	public Date getLastSyncTime() {
		return lastSyncTime;
	}

	public void setLastSyncTime(Date lastSyncTime) {
		this.lastSyncTime = lastSyncTime;
	}

	public String getNotificationEnabled() {
		return notificationEnabled;
	}

	public void setNotificationEnabled(String notificationEnabled) {
		this.notificationEnabled = notificationEnabled;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public boolean isDirectManaged() {
		return isDirectManaged;
	}

	public void setDirectManaged(boolean isDirectManaged) {
		this.isDirectManaged = isDirectManaged;
	}

	@JsonIgnore
	public SpEmsDetails getSpEmsDetails() {
		return spEmsDetails;
	}

	public void setSpEmsDetails(SpEmsDetails spEmsDetails) {
		this.spEmsDetails = spEmsDetails;
	}

	public List<SpProtocolSettings> getSpProtocolSettings() {
		return spProtocolSettings;
	}

	public void setSpProtocolSettings(List<SpProtocolSettings> spProtocolSettings) {
		this.spProtocolSettings = spProtocolSettings;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((addlParams == null) ? 0 : addlParams.hashCode());
		result = prime * result
				+ ((cleiCode == null) ? 0 : cleiCode.hashCode());
		result = prime * result + ((clli == null) ? 0 : clli.hashCode());
		result = prime * result
				+ ((deviceType == null) ? 0 : deviceType.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result
				+ ((ipAddress1 == null) ? 0 : ipAddress1.hashCode());
		result = prime * result
				+ ((ipAddress2 == null) ? 0 : ipAddress2.hashCode());
		result = prime * result + (isDirectManaged ? 1231 : 1237);
		result = prime * result
				+ ((lastSyncStatus == null) ? 0 : lastSyncStatus.hashCode());
		result = prime * result
				+ ((lastSyncTime == null) ? 0 : lastSyncTime.hashCode());
		result = prime * result
				+ ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime
				* result
				+ ((notificationEnabled == null) ? 0 : notificationEnabled
						.hashCode());
		result = prime * result
				+ ((referenceId == null) ? 0 : referenceId.hashCode());
		result = prime * result
				+ ((spEmsDetails == null) ? 0 : spEmsDetails.hashCode());
		result = prime
				* result
				+ ((spProtocolSettings == null) ? 0 : spProtocolSettings
						.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result
				+ ((updatedTime == null) ? 0 : updatedTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SpNode other = (SpNode) obj;
		if (addlParams == null) {
			if (other.addlParams != null)
				return false;
		} else if (!addlParams.equals(other.addlParams))
			return false;
		if (cleiCode == null) {
			if (other.cleiCode != null)
				return false;
		} else if (!cleiCode.equals(other.cleiCode))
			return false;
		if (clli == null) {
			if (other.clli != null)
				return false;
		} else if (!clli.equals(other.clli))
			return false;
		if (deviceType == null) {
			if (other.deviceType != null)
				return false;
		} else if (!deviceType.equals(other.deviceType))
			return false;
		if (id != other.id)
			return false;
		if (ipAddress1 == null) {
			if (other.ipAddress1 != null)
				return false;
		} else if (!ipAddress1.equals(other.ipAddress1))
			return false;
		if (ipAddress2 == null) {
			if (other.ipAddress2 != null)
				return false;
		} else if (!ipAddress2.equals(other.ipAddress2))
			return false;
		if (isDirectManaged != other.isDirectManaged)
			return false;
		if (lastSyncStatus != other.lastSyncStatus)
			return false;
		if (lastSyncTime == null) {
			if (other.lastSyncTime != null)
				return false;
		} else if (!lastSyncTime.equals(other.lastSyncTime))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (notificationEnabled == null) {
			if (other.notificationEnabled != null)
				return false;
		} else if (!notificationEnabled.equals(other.notificationEnabled))
			return false;
		if (referenceId == null) {
			if (other.referenceId != null)
				return false;
		} else if (!referenceId.equals(other.referenceId))
			return false;
		if (spEmsDetails == null) {
			if (other.spEmsDetails != null)
				return false;
		} else if (!spEmsDetails.equals(other.spEmsDetails))
			return false;
		if (spProtocolSettings == null) {
			if (other.spProtocolSettings != null)
				return false;
		} else if (!spProtocolSettings.equals(other.spProtocolSettings))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (updatedTime == null) {
			if (other.updatedTime != null)
				return false;
		} else if (!updatedTime.equals(other.updatedTime))
			return false;
		return true;
	}
	
	

}