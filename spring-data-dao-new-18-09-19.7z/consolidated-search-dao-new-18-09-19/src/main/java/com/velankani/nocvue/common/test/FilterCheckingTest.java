package com.velankani.nocvue.common.test;

import org.springframework.data.jpa.domain.Specification;

import com.velankani.consolidated.common.dao.filters.FilterSpecification;
import com.velankani.nocvue.eagger.useraction.model.SpJob;

public class FilterCheckingTest {

	public static void main(String[] args) {
		FilterSpecification<SpJob>  a=new FilterSpecification<SpJob>();
		Specification specs =  Specification.where(a.getStringTypeSpecification("firstName", ""));
	}

}
