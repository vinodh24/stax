package com.velankani.nocvue.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="sp_protocol_settings")
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class, property="id")
public class SpProtocolSettings implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_sp_protocol_settings")
	@SequenceGenerator(name = "seq_gen_sp_protocol_settings", sequenceName = "SEQ_SP_PROTOCOL_SETTINGS",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "username")
	private String userName;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "startport")
	private String startPort;
	
	@Column(name = "endport")
	private String endPort;
	
	@Column(name = "protocoltype")
	private String protocolType;
	
	@Column(name = "sync_retry_count")
	private Long syncRetryCount;
	
	@Column(name = "sessioncount")
	private Long sessionCount;
	
	@Column(name = "hb_interval")
	private Long hbInterval;
	
	@Column(name = "session_retry_count")
	private Long sessionRetryCount;
	
	@Column(name = "session_retry_intvl")
	private Long sessionRetryIntvl;
	
	@Column(name = "version")
	private String version;
	
	@Column(name = "description")
	private String description;
	
	@ManyToOne
	@JoinColumn(name="EMSID", referencedColumnName = "id")
	private SpEmsDetails spEmsDetails;
	
	@ManyToOne
	@JoinColumn(name="NODEID", referencedColumnName = "id")
	private SpNode spNode;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStartPort() {
		return startPort;
	}

	public void setStartPort(String startPort) {
		this.startPort = startPort;
	}

	public String getEndPort() {
		return endPort;
	}

	public void setEndPort(String endPort) {
		this.endPort = endPort;
	}

	public String getProtocolType() {
		return protocolType;
	}

	public void setProtocolType(String protocolType) {
		this.protocolType = protocolType;
	}

	public Long getSyncRetryCount() {
		return syncRetryCount;
	}

	public void setSyncRetryCount(Long syncRetryCount) {
		this.syncRetryCount = syncRetryCount;
	}

	public Long getSessionCount() {
		return sessionCount;
	}

	public void setSessionCount(Long sessionCount) {
		this.sessionCount = sessionCount;
	}

	public Long getHbInterval() {
		return hbInterval;
	}

	public void setHbInterval(Long hbInterval) {
		this.hbInterval = hbInterval;
	}

	public Long getSessionRetryCount() {
		return sessionRetryCount;
	}

	public void setSessionRetryCount(Long sessionRetryCount) {
		this.sessionRetryCount = sessionRetryCount;
	}

	public Long getSessionRetryIntvl() {
		return sessionRetryIntvl;
	}

	public void setSessionRetryIntvl(Long sessionRetryIntvl) {
		this.sessionRetryIntvl = sessionRetryIntvl;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SpEmsDetails getSpEmsDetails() {
		return spEmsDetails;
	}

	public void setSpEmsDetails(SpEmsDetails spEmsDetails) {
		this.spEmsDetails = spEmsDetails;
	}

	public SpNode getSpNode() {
		return spNode;
	}

	public void setSpNode(SpNode spNode) {
		this.spNode = spNode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((endPort == null) ? 0 : endPort.hashCode());
		result = prime * result
				+ ((hbInterval == null) ? 0 : hbInterval.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime * result
				+ ((protocolType == null) ? 0 : protocolType.hashCode());
		result = prime * result
				+ ((sessionCount == null) ? 0 : sessionCount.hashCode());
		result = prime
				* result
				+ ((sessionRetryCount == null) ? 0 : sessionRetryCount
						.hashCode());
		result = prime
				* result
				+ ((sessionRetryIntvl == null) ? 0 : sessionRetryIntvl
						.hashCode());
		result = prime * result
				+ ((spEmsDetails == null) ? 0 : spEmsDetails.hashCode());
		result = prime * result + ((spNode == null) ? 0 : spNode.hashCode());
		result = prime * result
				+ ((startPort == null) ? 0 : startPort.hashCode());
		result = prime * result
				+ ((syncRetryCount == null) ? 0 : syncRetryCount.hashCode());
		result = prime * result
				+ ((userName == null) ? 0 : userName.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SpProtocolSettings other = (SpProtocolSettings) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (endPort == null) {
			if (other.endPort != null)
				return false;
		} else if (!endPort.equals(other.endPort))
			return false;
		if (hbInterval == null) {
			if (other.hbInterval != null)
				return false;
		} else if (!hbInterval.equals(other.hbInterval))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (protocolType == null) {
			if (other.protocolType != null)
				return false;
		} else if (!protocolType.equals(other.protocolType))
			return false;
		if (sessionCount == null) {
			if (other.sessionCount != null)
				return false;
		} else if (!sessionCount.equals(other.sessionCount))
			return false;
		if (sessionRetryCount == null) {
			if (other.sessionRetryCount != null)
				return false;
		} else if (!sessionRetryCount.equals(other.sessionRetryCount))
			return false;
		if (sessionRetryIntvl == null) {
			if (other.sessionRetryIntvl != null)
				return false;
		} else if (!sessionRetryIntvl.equals(other.sessionRetryIntvl))
			return false;
		if (spEmsDetails == null) {
			if (other.spEmsDetails != null)
				return false;
		} else if (!spEmsDetails.equals(other.spEmsDetails))
			return false;
		if (spNode == null) {
			if (other.spNode != null)
				return false;
		} else if (!spNode.equals(other.spNode))
			return false;
		if (startPort == null) {
			if (other.startPort != null)
				return false;
		} else if (!startPort.equals(other.startPort))
			return false;
		if (syncRetryCount == null) {
			if (other.syncRetryCount != null)
				return false;
		} else if (!syncRetryCount.equals(other.syncRetryCount))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}
	
}
	