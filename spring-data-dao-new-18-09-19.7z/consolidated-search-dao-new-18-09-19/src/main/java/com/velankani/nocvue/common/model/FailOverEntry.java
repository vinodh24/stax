package com.velankani.nocvue.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "failoverentry")
@Data
public class FailOverEntry implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_failoverentry")
	@SequenceGenerator(name = "seq_gen_failoverentry", sequenceName = "SEQ_FAILOVERENTRY",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private Long id;
	@Column(name = "ipaddress")
	private String ipAddress;
	@Column(name = "port")
	private int port;
	@Column(name = "servermode")
	private String serverMode;
	@Column(name = "state")
	private String state;
	@Column(name = "serverstartuptime")
	private Long serverStartUpTime;
	@Column(name = "pollcountlastupdatedtime")
	private Long pollCountLastUpdatedTime;
	@Column(name = "pollcount")
	private Long pollCount;
	@Column(name = "servername")
	private String serverName;
	@Column(name = "servertype")
	private String serverType;
	@Column(name = "configname")
	private String configName;
	@Column(name = "deviceid")
	private String deviceId;
	@Column(name = "standbyfor")
	private Long standbyfor;
	@Column(name = "description")
	private String description;
	@Column(name = "location")
	private String location;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getServerMode() {
		return serverMode;
	}
	public void setServerMode(String serverMode) {
		this.serverMode = serverMode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Long getServerStartUpTime() {
		return serverStartUpTime;
	}
	public void setServerStartUpTime(Long serverStartUpTime) {
		this.serverStartUpTime = serverStartUpTime;
	}
	public Long getPollCountLastUpdatedTime() {
		return pollCountLastUpdatedTime;
	}
	public void setPollCountLastUpdatedTime(Long pollCountLastUpdatedTime) {
		this.pollCountLastUpdatedTime = pollCountLastUpdatedTime;
	}
	public Long getPollCount() {
		return pollCount;
	}
	public void setPollCount(Long pollCount) {
		this.pollCount = pollCount;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public String getServerType() {
		return serverType;
	}
	public void setServerType(String serverType) {
		this.serverType = serverType;
	}
	public String getConfigName() {
		return configName;
	}
	public void setConfigName(String configName) {
		this.configName = configName;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public Long getStandbyfor() {
		return standbyfor;
	}
	public void setStandbyfor(Long standbyfor) {
		this.standbyfor = standbyfor;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "FailOverEntry [id=" + id + ", ipAddress=" + ipAddress + ", port=" + port + ", serverMode=" + serverMode
				+ ", state=" + state + ", serverStartUpTime=" + serverStartUpTime + ", pollCountLastUpdatedTime="
				+ pollCountLastUpdatedTime + ", pollCount=" + pollCount + ", serverName=" + serverName + ", serverType="
				+ serverType + ", configName=" + configName + ", deviceId=" + deviceId + ", standbyfor=" + standbyfor
				+ ", description=" + description + ", location=" + location + "]";
	}
}
