package com.velankani.nocvue.common.repository;

import com.velankani.nocvue.common.model.SpAccessControl;


public interface SpAccessControlRepository  extends GenericDAO<SpAccessControl>{

}
