package com.velankani.nocvue.common.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "sp_settings")
public class SpSettings {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_sp_settings")
	@SequenceGenerator(name = "seq_gen_sp_settings", sequenceName = "SEQ_SP_SETTINGS",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private long id;
	
	@Column(name = "propertyname")
	private String propertyName;
	
	@Column(name = "propertyvalue")
	private String propertyValue;
	
	@Column(name = "units")
	private String units;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

}
