package com.velankani.nocvue.common.test;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.velankani.nocvue.common.model.Alarm;
import com.velankani.nocvue.common.repository.AlarmRepository;

public class BatchAlaramSave {
	
	@Autowired
	private AlarmRepository alarmRepository;
	
    public void saveAllAlaram(List<Alarm> alaramList){
    	alarmRepository.saveAll(alaramList);
	}
}
