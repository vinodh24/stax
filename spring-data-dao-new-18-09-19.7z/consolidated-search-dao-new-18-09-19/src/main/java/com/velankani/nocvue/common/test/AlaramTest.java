package com.velankani.nocvue.common.test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.velankani.consolidated.common.dao.service.CurdService;
import com.velankani.nocvue.common.model.Alarm;

public class AlaramTest {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springConfig.xml");
		CurdService curdOperation = (CurdService) context.getBean("curdRepository");
		System.out.println(curdOperation + "    ::::;curdOperation");
		
		List<Alarm> alarmList=new ArrayList<Alarm>();
		for(int i=0;i<60;i++){
			alarmList.add(getAlarm(i));
		}
		
		/*
		System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));	
		curdOperation.saveAlaram(null, alarmList);
		System.out.println("End time   "+new Timestamp(System.currentTimeMillis()));*/
		
		/*System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));
		curdOperation.findAllById(getAlaramIds());
		System.out.println("End time   "+new Timestamp(System.currentTimeMillis()));*/
		
		/*System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));
		curdOperation.findAll();
		System.out.println("End time   "+new Timestamp(System.currentTimeMillis()));*/
			
		/*findById(curdOperation);*/
		
		curdOperation.saveAlaram(null, alarmList);

	}
	
	public static Alarm getAlarm(int i){
		Alarm alarm=new Alarm();
		alarm.setAdditionalText("AdditionalTex");
		alarm.setAlarmSourceId("AlarmSourceId");
		alarm.setAlertIdentifier("AlertIdentifier"+i);
		alarm.setCategory("Category");
		alarm.setCreateTime(new Timestamp(System.currentTimeMillis()));
		alarm.setDescription("Description");
		alarm.setEmsId(i);
		alarm.setFailureObject("FailureObject");
		alarm.setFailureObjectDescription("FailureObjectDescription");
		alarm.setGeneratedSource("GeneratedSource");
		alarm.setModifiedTime(new Timestamp(System.currentTimeMillis()));
		alarm.setNodeName("NodeName");
		alarm.setOwner("Owner");
		alarm.setPreviousSeverity(5L);
		alarm.setProbableCause("ProbableCause");
		alarm.setSequenceNumber("SequenceNumber");
		alarm.setSeverity(10L);	
		return alarm;		
	}
	public static List<Long> getAlaramIds(){
		List<Long> ids=new ArrayList<Long>();
		for(long i=85;i<1085;i++){
			ids.add(i);
		}
		return ids;		
	}
	public static void findById(CurdService curdOperation){
		System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));
		for(long i=85;i<2085;i++){
			curdOperation.findById(i);
		}
		System.out.println("End time   "+new Timestamp(System.currentTimeMillis()));
	}

}
