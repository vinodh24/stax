package com.velankani.nocvue.common.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "spauditlogextn")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SpAuditLogExtn implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_spauditlogextn")
	@SequenceGenerator(name = "seq_gen_spauditlogextn", sequenceName = "SEQ_AUDIT_EXTN",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private Long id;

	@Column(name = "command")
	private String command;

	@Column(name = "response")
	private String response;

	@Column(name = "requesttime")
	private Date requestTime;

	@Column(name = "respondtime")
	private Date respondTime;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "status")
	private String status;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Date getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

	public Date getRespondTime() {
		return respondTime;
	}

	public void setRespondTime(Date respondTime) {
		this.respondTime = respondTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
