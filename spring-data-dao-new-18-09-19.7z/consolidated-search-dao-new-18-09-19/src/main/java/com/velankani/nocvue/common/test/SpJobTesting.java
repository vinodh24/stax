package com.velankani.nocvue.common.test;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.velankani.consolidated.common.dao.service.CurdService;
import com.velankani.nocvue.eagger.useraction.model.SpJob;
import com.velankani.nocvue.eagger.useraction.model.SpJobEnum;
import com.velankani.nocvue.eagger.useraction.model.SpTask;

public class SpJobTesting {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springConfig.xml");
		CurdService curdOperation = (CurdService) context.getBean("curdRepository");
		System.out.println(curdOperation + "    ::::;curdOperation");
       
		/*saveJobes(curdOperation);*/
		
		saveJobes1(curdOperation);
		
		/*findAllSpJob(curdOperation);*/
		
		/*findBySpJobId(curdOperation);*/
		
		/*findByUserName(curdOperation);*/
		
		/*curdOperation.findByUserName("nocvue123");*/
	}
	
	public static SpJob saveSpJob() {
		SpJob spJob = new SpJob();
		spJob.setJobId("nocvue_156834574145574");
		spJob.setUserName("nocvue123");
		spJob.setStartTime(new Timestamp(System.currentTimeMillis()));
		spJob.setEndTime(new Timestamp(System.currentTimeMillis()));
		spJob.setJobStatus(SpJobEnum.IN_PROGRESS);
		spJob.setOutputFilePath("D:/Product/Consolidated/batchFileFolders/nocvue_156834574145574/");
		spJob.setTaskCount(10L);
		spJob.setJobType("BATCH");
		spJob.setTaskCount(22L);
		getSpTaskList(spJob);
		return spJob;
	}
	public static void getSpTaskList(SpJob spJob){
		for(int i=0;i<50;i++){
		SpTask spTask=new SpTask();
		spTask.setDeviceName("ACTELISEMS-16");
		spTask.setEmsName("ACTELISEMS-16");
		spTask.setJobId("nocvue_156834574145574");
		spTask.setModel("Tellabs AccessMax");
		spTask.setOutputFilePath("D:/Product/Consolidated/batchFileFolders/nocvue_156834574145574/ACTELISEMS-16.txt");
		spTask.setTaskStatus(SpJobEnum.IN_PROGRESS);
		spTask.setVendor("Actelis EMS");
		spTask.setEndTime(new Timestamp(System.currentTimeMillis()));
		spTask.setStartTime(LocalDate.now());
		if(spJob != null)
		spJob.addSpTask(spTask);
		}
	}
	public static void saveJobes(CurdService curdOperation){
		List<SpJob> spJobList=new ArrayList<SpJob>();
		for(int i=0;i<10;i++){
			spJobList.add(saveSpJob());
		}
		
        System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));	
		for (int i = 0; i < spJobList.size(); i++) {
			curdOperation.saveJob(spJobList.get(i));
		}		
		System.out.println("End time "+new Timestamp(System.currentTimeMillis()));		
	}
	
	public static void findAllSpJob(CurdService curdOperation){
		 System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));
		 curdOperation.findAllSpJob();
		 System.out.println("End time "+new Timestamp(System.currentTimeMillis()));
	}
	public static void findBySpJobId(CurdService curdOperation){
		System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));
		for(long i=85;i<2085;i++){
		curdOperation.findBySpJobId(i);
		}
		System.out.println("End time "+new Timestamp(System.currentTimeMillis()));
	}
	public static void findByUserName(CurdService curdOperation){
		System.out.println("Start time "+new Timestamp(System.currentTimeMillis()));
		//curdOperation.findByUserName("nocvue123");
		System.out.println("End time "+new Timestamp(System.currentTimeMillis()));
	}
	public static SpJob saveSpJob1() {
		SpJob spJob = new SpJob();
		spJob.setJobId("nocvue_156834574145574");
		spJob.setUserName("nocvue123");
		spJob.setStartTime(new Timestamp(System.currentTimeMillis()));
		spJob.setEndTime(new Timestamp(System.currentTimeMillis()));
		spJob.setJobStatus(SpJobEnum.IN_PROGRESS);
		spJob.setOutputFilePath("D:/Product/Consolidated/batchFileFolders/nocvue_156834574145574/");
		spJob.setTaskCount(10L);
		spJob.setJobType("BATCH");
		spJob.setTaskCount(22L);
		getSpTaskList1(spJob);
		return spJob;
	}
	public static void getSpTaskList1(SpJob spJob){
		SpTask spTask=new SpTask();
		spTask.setDeviceName("ACTELISEMS-16");
		spTask.setEmsName("ACTELISEMS-16");
		spTask.setJobId("nocvue_156834574145574");
		spTask.setModel("Tellabs AccessMax");
		spTask.setOutputFilePath("D:/Product/Consolidated/batchFileFolders/nocvue_156834574145574/ACTELISEMS-16.txt");
		spTask.setTaskStatus(SpJobEnum.IN_PROGRESS);
		spTask.setVendor("Actelis EMS");
		spTask.setEndTime(new Timestamp(System.currentTimeMillis()));
		spTask.setStartTime(LocalDate.now());
		spJob.addSpTask(spTask);
	}
	public static SpJob saveSpJob2(int i) {
		SpJob spJob = new SpJob();
		spJob.setJobId("nocvue_156834574145574");
		spJob.setUserName("nocvue123"+i);
		spJob.setStartTime(new Timestamp(System.currentTimeMillis()));
		spJob.setEndTime(new Timestamp(System.currentTimeMillis()));
		spJob.setJobStatus(SpJobEnum.IN_PROGRESS);
		spJob.setOutputFilePath("D:/Product/Consolidated/batchFileFolders/nocvue_156834574145574/");
		spJob.setTaskCount(10L+i);
		spJob.setJobType("BATCH"+i);
		spJob.setTaskCount(22L);
		getSpTaskList2(spJob,i);
		return spJob;
	}
	public static void getSpTaskList2(SpJob spJob,int i){
		SpTask spTask=new SpTask();
		spTask.setDeviceName("ACTELISEMS-16"+i);
		spTask.setEmsName("ACTELISEMS-16"+i);
		spTask.setJobId("nocvue_156834574145574"+i);
		spTask.setModel("Tellabs AccessMax");
		spTask.setOutputFilePath("D:/Product/Consolidated/batchFileFolders/nocvue_156834574145574/ACTELISEMS-16.txt");
		spTask.setTaskStatus(SpJobEnum.IN_PROGRESS);
		spTask.setVendor("Actelis EMS");
		spTask.setEndTime(new Timestamp(System.currentTimeMillis()));
		spTask.setStartTime(LocalDate.now());
		spJob.addSpTask(spTask);
	}
	
	public static void saveJobes1(CurdService curdOperation){
		List<SpJob> spJobList=new ArrayList<SpJob>();
		List<SpJob> spJobList1=new ArrayList<SpJob>();
		for(int i=0;i<=10;i++){
			spJobList.add(saveSpJob1());
		}
		for(int i=11;i<=20;i++){
			spJobList1.add(saveSpJob2(i));
		}
		System.out.println(spJobList.size()+"       ************************                 "+spJobList1.size());
		curdOperation.saveAllAlaram(spJobList1, spJobList1);
	}
	
}
