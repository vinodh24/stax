package com.velankani.nocvue.common.repository;

import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.velankani.nocvue.eagger.useraction.model.SpJobEnum;
import com.velankani.nocvue.eagger.useraction.model.SpTask;

public interface SpTaskRepository extends GenericDAO<SpTask>{

	@Query @Transactional @Modifying
	int updateSpTask(SpJobEnum taskStatus,Timestamp startTime,Timestamp endTime,String remark,String deviceName, String jobId);
	
	@Query
	List<SpTask> findBySpJobId(Long jobDbId);
}
