package com.velankani.nocvue.common.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "spauditlog")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SpAuditLog implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_gen_spauditlog")
	@SequenceGenerator(name = "seq_gen_spauditlog", sequenceName = "SEQ_AUDIT_LOG",allocationSize = 1, initialValue = 1)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "category")
	private String category;
	
	@Column(name = "username")
	private String username;
	
	@Column(name = "cuid")
	private String cuId;
	
	@Column(name = "mgrcuid")
	private String mgrcuId;
	
	@Column(name = "emsname")
	private String emsName;
	
	@Column(name = "emsip")
	private String emsIp;
	
	@Column(name = "node")
	private String nodeName;
	
	@Column(name = "nodeip")
	private String nodeIp;
	
	@Column(name = "vendor")
	private String vendor;
	
	@Column(name = "deviceType")
	private String deviceType;
	
	@Column(name = "operation")
	private String operation;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "remarks")
	private String remarks;
	
	@Column(name = "requesttime")
	private Timestamp requestTime;
	
	@Column(name = "respondtime")
	private Timestamp respondTime;
	
	@Column(name = "jobid")
	private String jobId;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "parentid", referencedColumnName = "id",nullable=false)
	private Set<SpAuditLogExtn> spAuditLogExtns;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCuId() {
		return cuId;
	}

	public void setCuId(String cuId) {
		this.cuId = cuId;
	}

	public String getMgrcuId() {
		return mgrcuId;
	}

	public void setMgrcuId(String mgrcuId) {
		this.mgrcuId = mgrcuId;
	}

	public String getEmsName() {
		return emsName;
	}

	public void setEmsName(String emsName) {
		this.emsName = emsName;
	}

	public String getEmsIp() {
		return emsIp;
	}

	public void setEmsIp(String emsIp) {
		this.emsIp = emsIp;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getNodeIp() {
		return nodeIp;
	}

	public void setNodeIp(String nodeIp) {
		this.nodeIp = nodeIp;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Timestamp getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(Timestamp requestTime) {
		this.requestTime = requestTime;
	}

	public Timestamp getRespondTime() {
		return respondTime;
	}

	public void setRespondTime(Timestamp respondTime) {
		this.respondTime = respondTime;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public Set<SpAuditLogExtn> getSpAuditLogExtns() {
		if(spAuditLogExtns == null){
			spAuditLogExtns = new HashSet<SpAuditLogExtn>();
		}
		return spAuditLogExtns;
	}

	public void setSpAuditLogExtns(Set<SpAuditLogExtn> spAuditLogExtns) {
		this.spAuditLogExtns = spAuditLogExtns;
	}
}
