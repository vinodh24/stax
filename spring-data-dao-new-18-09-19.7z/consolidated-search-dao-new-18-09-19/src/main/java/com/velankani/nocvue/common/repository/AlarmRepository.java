package com.velankani.nocvue.common.repository;

import java.util.List;
import java.util.Optional;

import com.velankani.nocvue.common.model.Alarm;

public interface AlarmRepository extends GenericDAO<Alarm>{
	
	@Override
	public Optional<Alarm> findById(Long id);
	
	@Override
	public List<Alarm> findAll();

}
