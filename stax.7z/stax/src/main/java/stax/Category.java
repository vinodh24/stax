package stax;

public enum Category {
    FICTION,
    PASCAL,
    PROGRAMMING
}