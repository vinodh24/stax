package com.xmltomap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.xml.stream.XMLStreamException;

import stax.Main;

public class main {
	public static void main(String[] args) throws IOException, XMLStreamException {
		//System.out.println("test......");
        try (InputStream is = Main.class.getResourceAsStream("/example.xml")) {
            if (is == null)
                throw new IOException("Failed to open resource");
            xmlReader1 xmlReader1 = new xmlReader1();
            String xmlString=convert(is);
            System.out.println("\n\nddd    :::"+xmlReader1.readFromXML(xmlString));
        }
    }
	public static String convert(InputStream inputStream) throws IOException {
		 
		StringBuilder stringBuilder = new StringBuilder();
		String line = null;
		
		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream))) {	
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
			}
		}
	 
		return stringBuilder.toString();
	}
}
