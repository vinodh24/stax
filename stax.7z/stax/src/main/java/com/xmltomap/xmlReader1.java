package com.xmltomap;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.json.JSONObject;

public class xmlReader1 {
	public List<Map<String,String>> readFromXML(InputStream is) throws XMLStreamException {
		XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		XMLStreamReader reader = null;
		try {
			reader = inputFactory.createXMLStreamReader(is);
			return readDocument(reader);
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
	}
	public List<Map<String,String>> readFromXML(String xml) throws XMLStreamException {
		XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		XMLStreamReader reader = null;
		try {
			reader = inputFactory.createXMLStreamReader(new ByteArrayInputStream(xml.getBytes()));
			return readDocument(reader);
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
	}

	private List<Map<String, String>> readDocument(XMLStreamReader reader) throws XMLStreamException {
		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.START_ELEMENT:
				String elementName = reader.getLocalName();
				System.out.println("elementName ::: "+elementName);
				if (elementName.equals("data")){    
					return readData(reader);
				}else{
					readData(reader);
				}
				break;
			case XMLStreamReader.END_ELEMENT:
				break;
			}
		}
		throw new XMLStreamException("Premature end of file");
	}
	private List<Map<String, String>> readData(XMLStreamReader reader) throws XMLStreamException {
		List<Map<String,String>> ResponseElement = new ArrayList<>();

		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.START_ELEMENT:
				String elementName = reader.getLocalName();
				if (elementName.equals("person")) {
						ResponseElement.add(readResponseElement(reader)); 					
				} else {
					readResponseElement(reader);
				}
				break;       
			case XMLStreamReader.END_ELEMENT:
				System.out.println("END_ELEMENT  ::: "+ResponseElement);
				return ResponseElement;
			}
		}
		throw new XMLStreamException("Premature end of file");
	}
	
	private Map<String, String> readResponseElement(XMLStreamReader reader) throws XMLStreamException {
		Map<String,String> ResponseElement=new HashMap<String,String>();
		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.START_ELEMENT:
				String elementName = reader.getLocalName();
				ResponseElement.put(elementName,readCharacters(reader));
				break;
			case XMLStreamReader.END_ELEMENT:
				return ResponseElement;
			}
		}
		throw new XMLStreamException("Premature end of file");
	}
	private String readCharacters(XMLStreamReader reader) throws XMLStreamException {
		StringBuilder result = new StringBuilder();
		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.CHARACTERS:
			case XMLStreamReader.CDATA:
				result.append(reader.getText());
				break;
			case XMLStreamReader.END_ELEMENT:
				return result.toString();
			}
		}
		throw new XMLStreamException("Premature end of file");
	}
	public static JSONObject getJsongData(){
    	JSONObject json = new JSONObject();
    	json.put("Root_Group","Root_");
    	json.put("ifIndex","Ind");
    	json.put("DynOmciCpeConnection_Id","DynOmciCpeConnection_Id");
    	json.put("ctmIndex","ctm");
    	json.put("groupTemplate","groupTemplate");
    	json.put("videoGport","videoGport");
    	json.put("Handle_Type","Handle_Type");
    	json.put("ifVlanFilled","ifVlanFilled");
    	json.put("tpType","tpType");
    	json.put("realCpeConnDeleted","realCpeConnDeleted");
    	json.put("slanTpId","slanTpId");
    	json.put("internalMe","internalMe");
    	json.put("vlanTpId","vlanTpId");
    	json.put("tpIndex","tpInd");
    	json.put("phySlotId","phySlotId");
    	json.put("phyShelfId","phyShelfId");
    	json.put("slanCos","slanCos");
    	json.put("rgMode","rgMode");
    	json.put("slanXlateTpId","slanXlateTpId");
    	json.put("egressGroupTemplate","egressGroupTemplate");
    	json.put("vlanXlateTpId","vlanXlateTpId");
    	json.put("vlanId","1vlanId");
    	json.put("Region_Id","Region_Id");
    	json.put("floodingGport","0");
    	json.put("groupIndex","floodingGport");
    	json.put("gponOnuId","gponOnuId");
    	json.put("Device_Group","Device_Group");
    	json.put("Region_Type","Region_Type");
    	json.put("vlanXlateCos","vlanXlateCos");
    	json.put("egressGroupIndex","egressGroupIndex");
    	json.put("name","name");
    	json.put("autoSelectGem","autoSelectGem");
    	json.put("status","status");
    	json.put("dscpToCosIndex","dscpToCosIndex");
    	json.put("Root_Type","Root");
    	json.put("Description","desc");
    	json.put("gponPortId","gponPortId");
    	json.put("slanXlateCos","slanXlateCos");
    	json.put("Timestamp","time");
    	json.put("phyPortId","phyPortId");
    	json.put("vlanCos","vlanCos");
    	json.put("Handle_Id","Handle_Id");
    	json.put("Device_Id","Device_Id");
    	json.put("gponTrafficIdx","gponTrafficIdx");
    	json.put("slanXlateId","slanXlateId");
    	json.put("bridgeIfMcastControlList","bridgeIfMcastControlList");
    	json.put("slanId","slanId");
    	json.put("Handle_Group","Handle_Group");
    	json.put("bridgeTemplateName","bridgeTemplateName");
    	json.put("gtpTemplateName","gtpTemplateName");
    	json.put("bridgeIfMaxVideoStreams","bridgeIfMaxVideoStreams");
    	json.put("bridgeIfIndex","bridgeIfIndex");
    	json.put("Root_Id","Root_Id");
    	json.put("vlanXlateId","vlanXlateId");
    	json.put("guidedVlanId","guidedVlanId");
    	json.put("Device_Type","Device_Type");
    	json.put("DynOmciCpeConnection_Type","DynOmciCpeConnection_Type");
    	json.put("mvrVlanId","mvrVlanId");
    	json.put("realCpeConnAdded","realCpeConnAdded");
    	json.put("DynOmciCpeConnection_Group","DynOmciCpeConnection_Group");
    	json.put("Region_Group","Region_Group");
    	return json;
    }
}
