package com.velankani.consolidated.test;

import org.springframework.util.Assert;

public class SpringAssertTest {
	private static String[] array={"f"};
	public static void main(String[] args) {
		
		Assert.isTrue(array.length>0, " Invalid Command format");
		Assert.hasLength("1","Test case failed");
	}
}
