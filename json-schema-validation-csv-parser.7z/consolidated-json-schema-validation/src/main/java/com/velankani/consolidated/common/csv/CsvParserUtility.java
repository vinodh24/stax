package com.velankani.consolidated.common.csv;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.core.io.ClassPathResource;

import com.univocity.parsers.common.processor.BeanListProcessor;
import com.univocity.parsers.common.processor.BeanWriterProcessor;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

public class CsvParserUtility {
	
	public static <T> List<T> csvReader(String fileName, Class<T> clazz)throws FileNotFoundException, IOException {
		BeanListProcessor<T> rowProcessor = new BeanListProcessor<T>(clazz);
		CsvParserSettings parserSettings = new CsvParserSettings();
		parserSettings.setProcessor(rowProcessor);
		parserSettings.setDelimiterDetectionEnabled(true);
		parserSettings.setHeaderExtractionEnabled(true);
		CsvParser parser = new CsvParser(parserSettings);
		parser.parse(new FileReader(new ClassPathResource(fileName).getFile()));
		List<T> beans = rowProcessor.getBeans();
		return beans;
	}
	
	public static <T> void csvWriter(String filePath, Iterable<T> records,
							Class<T> clazz) throws FileNotFoundException {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
		CsvWriterSettings settings = new CsvWriterSettings();
		settings.setRowWriterProcessor(new BeanWriterProcessor<T>(clazz));
		CsvWriter csvWriter = new CsvWriter(bos, settings);
		System.out.println(csvWriter.getRecordCount());
		csvWriter.writeHeaders();
		csvWriter.processRecords(records);
		csvWriter.close();
	}
	
}
