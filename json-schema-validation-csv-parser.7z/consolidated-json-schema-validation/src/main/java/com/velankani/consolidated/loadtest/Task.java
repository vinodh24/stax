package com.velankani.consolidated.loadtest;

import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;


public class Task implements Runnable {
	private OfflineBatchRequest request;
	private RestTemplate restTemplate;
	private String uri;

	public Task(OfflineBatchRequest request, RestTemplate restTemplate, String uri) {
		this.request = request;
		this.restTemplate=restTemplate;
		this.uri=uri;
	}

	private void batchOperation(OfflineBatchRequest request) {
		Assert.notNull(uri, "'url' must not be null");
		Assert.notNull(restTemplate, "'restTemplate' must not be null");
		ResponseDto result = restTemplate.postForObject(uri, request,ResponseDto.class);
		System.out.println("-----------------------------------------------------------");
		System.out.println("::::::::"+result);
		System.out.println("-----------------------------------------------------------");
	}

	@Override
	public void run() {
		batchOperation(request);
	}
}
