package com.velankani.consolidated.loadtest;

import java.util.Arrays;
import java.util.List;

public class OfflineBatchRequest {
    
	private List<TargetDevice> targetDevice;
	private String username;
	private String jobName;
	private String jobId;
	private String fileName;
	private String[] command;
	public List<TargetDevice> getTargetDevice() {
		return targetDevice;
	}
	public void setTargetDevice(List<TargetDevice> targetDevice) {
		this.targetDevice = targetDevice;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String[] getCommand() {
		return command;
	}
	public void setCommand(String[] command) {
		this.command = command;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	@Override
	public String toString() {
		return "OfflineBatchRequest [targetDevice=" + targetDevice
				+ ", username=" + username + ", jobName=" + jobName
				+ ", jobId=" + jobId + ", fileName=" + fileName + ", command="
				+ Arrays.toString(command) + "]";
	}
}
