package com.velankani.consolidated.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.velankani.consolidated.loadtest.ExecuteBatchDto;



public class Test {
	public static void main(String[] args) throws Exception {
		ExecuteBatchDto executeBatchDto=new ExecuteBatchDto();
		String[] command={"RTRV-ALM-ALL:ADTRANOPTI-13038::;",
		                   "RTRV-VLAN-ALL:ADTRANOPTI-13038::;"};
		executeBatchDto.setCommand(command);
		executeBatchDto.setNodeName("vinodh");
		System.out.println(setTl1FormateCommand(executeBatchDto));
	}

	private static ExecuteBatchDto setTl1FormateCommand(ExecuteBatchDto executeBatchDto) throws Exception {
		List<String> commandList=new ArrayList<String>();
		for (String command : executeBatchDto.getCommand()) {
			 StringBuffer setCommand = new StringBuffer();
			 String[] array=command.split(":");
			 if(array.length > 1) {
			for (int i = 0; i < array.length; i++) {
				if( i == 0) {
					setCommand.append(array[i]);
				} else if(i==1) {
					setCommand.append(":".concat(executeBatchDto.getNodeName()));
				} else {
					setCommand.append(":".concat(array[i]));
				}
			 }
		   } else {
			   throw new Exception("Invalid Command");
		   }
			commandList.add(setCommand.toString());
		}
		 String[] listOfCommand = Arrays.copyOf(commandList.toArray(), commandList.size(),String[].class); 
		executeBatchDto.setCommand(listOfCommand);	
		return executeBatchDto;		
	}
	
}
