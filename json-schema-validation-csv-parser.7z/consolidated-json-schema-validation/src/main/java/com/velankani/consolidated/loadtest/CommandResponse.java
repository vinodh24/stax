package com.velankani.consolidated.loadtest;


public class CommandResponse {
	
	private String command;
	private String response;
	private String trackingId;
	private String message;
	private String fileName;
	private String jobName;
	
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	@Override
	public String toString() {
		return "CommandResponse [command=" + command + ", response=" + response
				+ ", trackingId=" + trackingId + ", message=" + message
				+ ", fileName=" + fileName + ", jobName=" + jobName + "]";
	}
	
	
}
