package com.velankani.consolidated.loadtest;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

public class ExecuteBatchDto {
	
    private String nodeIp;
    private String emsIp;
    private String emsName;
    private String vendor;
    private String tl1UserName;
    private String password;
    private String nodeName;
    private String deviceType;
    private String clli;
    private String startPort;
    private String endPort;
	private String[] command;
	private List<String> response;
    private Timestamp startTime;	
	private Timestamp endTime; 
	private String jobId;
	private String outPutFilePath;
	private String rootFolderPath;
	private boolean isDirectManaged;
	public String getNodeIp() {
		return nodeIp;
	}
	public void setNodeIp(String nodeIp) {
		this.nodeIp = nodeIp;
	}
	public String getEmsIp() {
		return emsIp;
	}
	public void setEmsIp(String emsIp) {
		this.emsIp = emsIp;
	}
	public String getEmsName() {
		return emsName;
	}
	public void setEmsName(String emsName) {
		this.emsName = emsName;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getTl1UserName() {
		return tl1UserName;
	}
	public void setTl1UserName(String tl1UserName) {
		this.tl1UserName = tl1UserName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNodeName() {
		return nodeName;
	}
	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getStartPort() {
		return startPort;
	}
	public void setStartPort(String startPort) {
		this.startPort = startPort;
	}
	public String getEndPort() {
		return endPort;
	}
	public void setEndPort(String endPort) {
		this.endPort = endPort;
	}
	public String[] getCommand() {
		return command;
	}
	public void setCommand(String[] command) {
		this.command = command;
	}
	public List<String> getResponse() {
		return response;
	}
	public void setResponse(List<String> response) {
		this.response = response;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Timestamp getEndTime() {
		return endTime;
	}
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getOutPutFilePath() {
		return outPutFilePath;
	}
	public void setOutPutFilePath(String outPutFilePath) {
		this.outPutFilePath = outPutFilePath;
	}
	public String getRootFolderPath() {
		return rootFolderPath;
	}
	public void setRootFolderPath(String rootFolderPath) {
		this.rootFolderPath = rootFolderPath;
	}
	
	public boolean isDirectManaged() {
		return isDirectManaged;
	}
	public void setDirectManaged(boolean isDirectManaged) {
		this.isDirectManaged = isDirectManaged;
	}
	
	public String getClli() {
		return clli;
	}
	public void setClli(String clli) {
		this.clli = clli;
	}
	@Override
	public String toString() {
		return "ExecuteBatchDto [nodeIp=" + nodeIp + ", emsIp=" + emsIp + ", emsName=" + emsName + ", vendor=" + vendor
				+ ", tl1UserName=" + tl1UserName + ", password=" + password + ", nodeName=" + nodeName + ", deviceType="
				+ deviceType + ", startPort=" + startPort + ", endPort=" + endPort + ", command="
				+ Arrays.toString(command) + ", response=" + response + ", startTime=" + startTime + ", endTime="
				+ endTime + ", jobId=" + jobId + ", outPutFilePath=" + outPutFilePath + ", rootFolderPath=" + rootFolderPath
				+ "]";
	}
}
