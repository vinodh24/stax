package com.velankani.consolidated.test;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.velankani.consolidated.common.util.JsonMapperUtil;
import com.velankani.consolidated.loadtest.OfflineBatchRequest;
import com.velankani.consolidated.loadtest.ReadJsonFile;

public class TestMaper {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		String request=ReadJsonFile.readJsonFile("batchRequest.json");
		OfflineBatchRequest offlineBatchRequest=JsonMapperUtil.mapFromJson(request, OfflineBatchRequest.class);
		System.out.println("OfflineBatchRequest = "+ offlineBatchRequest);
		String json=JsonMapperUtil.mapToJson(offlineBatchRequest);
		System.out.println(json);
	}
}
