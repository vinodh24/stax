package com.velankani.consolidated.loadtest;

public class ResponseDto {

	private int responseCode;
	private String responseMessage;
	private CommandResponse content;
	
	public int getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public CommandResponse getContent() {
		return content;
	}
	public void setContent(CommandResponse content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "ResponseDto [responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + ", content="
				+ content + "]";
	}
}
