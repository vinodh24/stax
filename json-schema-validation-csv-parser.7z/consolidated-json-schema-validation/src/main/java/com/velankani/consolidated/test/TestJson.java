package com.velankani.consolidated.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.LogLevel;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

public class TestJson {

	public static void main(String[] args) throws IOException, ProcessingException {
		@SuppressWarnings("resource")
		BufferedReader br = new BufferedReader(new FileReader(new ClassPathResource("settingsrequest.json").getFile()));
		String str="";
		String st; 
		while ((st = br.readLine()) != null) 
			str = str +st;
		String jsonValidationResponse =jsonValidation(str, "settingsschema");
		System.out.println("jsonValidationResponse :"+jsonValidationResponse);
	} 
	
	public static String jsonValidation(String jsonString, String value) throws IOException {
		JsonNode JsonNodeServiceFile = null;
		ObjectMapper mapper = new ObjectMapper();
		JsonNode serviceJsonNode = mapper.readTree(jsonString);
     	JsonNodeServiceFile = loadResource(value+".json");	
		final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
		JsonSchema fileSchema;
		ProcessingReport result = null;

		try {
			fileSchema = factory.getJsonSchema(JsonNodeServiceFile);
			result = fileSchema.validate(serviceJsonNode);
			//String error=getErrorsList(result, result.isSuccess());
			String error=getMissingKeys(result);
			System.out.println("   :::::::::: "+error.trim()+":::error");
		} catch (ProcessingException e) {
			System.out.println("kkkkkkkkk:"+e.getMessage());
		}
		return result+"";
	}
	public static String getErrorsList(ProcessingReport report, boolean onlyErrors) {
	    StringBuilder jsonValidationErrors = new StringBuilder();
	    for (ProcessingMessage processingMessage : report) {
	        if(onlyErrors && LogLevel.ERROR.equals(processingMessage.getLogLevel())) {
	            jsonValidationErrors.append(processingMessage.getMessage()).append("\n\r");
	        } else if(!onlyErrors) {
	            jsonValidationErrors.append(processingMessage.getMessage()).append("\n\r");
	        }
	    }
	    return jsonValidationErrors.toString().trim();
	}
	/*public static String getMissingKeys(ProcessingReport processingReport){
		 for (ProcessingMessage processingMessage : processingReport) {
	            String pointer = processingMessage.asJson().get("instance").get("pointer").asText();
	            System.out.println(pointer + " : " + processingMessage.getMessage());
	        }
		return "";
	}*/
	public static String getMissingKeys(ProcessingReport processingReport){
		StringBuilder jsonValidationErrors = new StringBuilder();
		for (ProcessingMessage processingMessage : processingReport) {
			 jsonValidationErrors.append(processingMessage.getMessage());    
	        }
		return jsonValidationErrors.toString().trim();
	}
	
	
	public static JsonNode loadResource(String name) throws IOException {
		return JsonLoader.fromResource("/" + name);
	}
}
