package com.velankani.consolidated.loadtest;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorServiceBatchTest {
	
	public static void main(String[] args) throws ExecutionException, InterruptedException, FileNotFoundException, IOException {
		ExecutorService service = null;
		String uri="http://localhost:9090/mas/batch/executeBatch";
		RestTemplateConfig restTemplate=new RestTemplateConfig();
		String request=ReadJsonFile.readJsonFile("batchRequest.json");
		OfflineBatchRequest offlineBatchRequest=ReadJsonFile.convertPojo(request);
		service = Executors.newFixedThreadPool(100);
		Task task=new Task(offlineBatchRequest,restTemplate.getRestTemplate(),uri);
		try {
			/*for(int i=0;i<100;i++){
				service.execute(task);
			}*/
			service.execute(task);
					
		}finally{
			if(service!=null){
				service.shutdown();
			}
		}
		
	}
	
}
