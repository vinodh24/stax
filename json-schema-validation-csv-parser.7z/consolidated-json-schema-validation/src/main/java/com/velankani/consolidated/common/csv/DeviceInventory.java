package com.velankani.consolidated.common.csv;

import com.univocity.parsers.annotations.Parsed;
import com.univocity.parsers.annotations.Trim;

public class DeviceInventory {
	@Trim@Parsed(defaultNullRead = "",field = {"ip_address", "ipAddress"})
	private String ipAddress;
	@Trim@Parsed
	private String vendor;
	@Trim@Parsed
	private String location;
	@Trim@Parsed
	private String userName;
	@Trim@Parsed
	private String password;
	@Trim@Parsed
	private int startPort;
	@Trim@Parsed
	private int endPort;
	@Trim@Parsed
	private int sessionCount;
	@Trim@Parsed
	private Long retryCount;
	@Trim@Parsed
	private String tid;
	@Trim@Parsed
	private String emsName;
	@Trim@Parsed
	private String result;
	
	
	
	public String getVendor() {
		return vendor;
	}
	public String getLocation() {
		return location;
	}
	public String getUserName() {
		return userName;
	}
	public String getPassword() {
		return password;
	}
	public int getStartPort() {
		return startPort;
	}
	public int getEndPort() {
		return endPort;
	}
	public int getSessionCount() {
		return sessionCount;
	}
	public Long getRetryCount() {
		return retryCount;
	}
	public String getTid() {
		return tid;
	}
	public String getEmsName() {
		return emsName;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setStartPort(int startPort) {
		this.startPort = startPort;
	}
	public void setEndPort(int endPort) {
		this.endPort = endPort;
	}
	public void setSessionCount(int sessionCount) {
		this.sessionCount = sessionCount;
	}
	public void setRetryCount(Long retryCount) {
		this.retryCount = retryCount;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	public void setEmsName(String emsName) {
		this.emsName = emsName;
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	@Override
	public String toString() {
		return "DeviceInventory [ipAddress=" + ipAddress + ", vendor=" + vendor
				+ ", location=" + location + ", userName=" + userName
				+ ", password=" + password + ", startPort=" + startPort
				+ ", endPort=" + endPort + ", sessionCount=" + sessionCount
				+ ", retryCount=" + retryCount + ", tid=" + tid + ", emsName="
				+ emsName + ", result=" + result + "]";
	}
	
}
