package com.velankani.consolidated.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.velankani.consolidated.common.csv.CsvParserUtility;
import com.velankani.consolidated.common.csv.DeviceInventory;
import com.velankani.consolidated.common.util.JsonMapperUtil;

public class DeviceInventroyJsonSchemaTest {

	public static void main(String[] args) throws IOException, ProcessingException {
		@SuppressWarnings("resource")
		BufferedReader br = new BufferedReader(new FileReader(new ClassPathResource("inventory_json_request.json").getFile()));
		String str="";
		String st; 
		while ((st = br.readLine()) != null) 
			str = str +st;
	    List<DeviceInventory> beans = CsvParserUtility.csvReader("Inventory_Sample_Format.csv",DeviceInventory.class);
		for (DeviceInventory deviceInventory : beans) {
			 System.out.println("tid::::::  "+deviceInventory.getTid());
			 String deviceInvertoryJson=JsonMapperUtil.mapToJson(deviceInventory);
			 System.out.println(deviceInvertoryJson);
			 String jsonValidationResponse =jsonValidation(deviceInvertoryJson, "inventory_jsong_schema");
			 System.out.println("jsonValidationResponse :"+jsonValidationResponse);
		}
       /*    String jsonValidationResponse =jsonValidation(str, "inventory_jsong_schema"); */		
	} 
	
	public static String jsonValidation(String jsonString, String value) throws IOException {
		JsonNode JsonNodeServiceFile = null;
		ObjectMapper mapper = new ObjectMapper();
		JsonNode serviceJsonNode = mapper.readTree(jsonString);
     	JsonNodeServiceFile = loadResource(value+".json");	
		final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
		JsonSchema fileSchema;
		ProcessingReport result = null;

		try {
			fileSchema = factory.getJsonSchema(JsonNodeServiceFile);
			result = fileSchema.validate(serviceJsonNode);
			//String error=getErrorsList(result, result.isSuccess());
			String error=getMissingKeys(result);
			System.out.println("   :::::::::: "+error.trim()+":::error");
		} catch (ProcessingException e) {
			System.out.println("kkkkkkkkk:"+e.getMessage());
		}
		return result+"";
	}
	public static JsonNode loadResource(String name) throws IOException {
		return JsonLoader.fromResource("/" + name);
	}
	public static String getMissingKeys(ProcessingReport processingReport){
		StringBuilder jsonValidationErrors = new StringBuilder();
		for (ProcessingMessage processingMessage : processingReport) {
			 jsonValidationErrors.append(processingMessage.getMessage());    
	        }
		return jsonValidationErrors.toString().trim();
	}
}
