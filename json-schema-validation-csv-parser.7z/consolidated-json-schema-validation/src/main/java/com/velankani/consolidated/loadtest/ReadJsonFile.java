package com.velankani.consolidated.loadtest;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ReadJsonFile {

	@SuppressWarnings("resource")
	public static String readJsonFile(String fileName) throws FileNotFoundException, IOException{
		BufferedReader br = new BufferedReader(new FileReader(new ClassPathResource(fileName).getFile()));
		String str="";
		String st; 
		while ((st = br.readLine()) != null) 
			str = str +st;
		return str;
	}
	public static OfflineBatchRequest convertPojo(String batchRequest){
		ObjectMapper mapper = new ObjectMapper();
		OfflineBatchRequest request=null;
		try {
			request = mapper.readValue(batchRequest,OfflineBatchRequest.class);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return request;
	}
	
	/*public static void main(String[] args) throws FileNotFoundException, IOException {
		System.out.println(readJsonFile("batchRequest.json"));
	}*/
	
}
