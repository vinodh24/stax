package com.velankani.consolidated.loadtest;


public class TargetDevice {

	private String nodeIp;
	private String emsIp;
	
	@Override
	public String toString() {
		return "TargetDevice [nodeIp=" + nodeIp + ", emsIp=" + emsIp + "]";
	}
	
	public String getNodeIp() {
		return nodeIp;
	}
	public void setNodeIp(String nodeIp) {
		this.nodeIp = nodeIp;
	}
	public String getEmsIp() {
		return emsIp;
	}
	public void setEmsIp(String emsIp) {
		this.emsIp = emsIp;
	}
}
