package com.velankani.consolidated.test;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;

public class NullCheckUtility {

	/*public static Boolean requireNonNull(Object obj) {
		return obj == null || obj.toString().trim().isEmpty();
	}*/

	/*public static boolean requireNonNull(Collection<?> obj) {
		return obj == null || obj.isEmpty();
	}*/

	/*public static boolean requireNonNull(String str) {
		return (str == null || str.trim().isEmpty() || "".equals(str));
	}*/

	public static boolean requireNonNull(Object obj) {
		if (obj == null) {
			return true;
		}
		if (obj instanceof Optional) {
			return !((Optional<?>) obj).isPresent();
		}
		if (obj instanceof CharSequence) {
			return ((CharSequence) obj).length() == 0;
		}
		if (obj.getClass().isArray()) {
			return Array.getLength(obj) == 0;
		}
		if (obj instanceof Collection) {
			return ((Collection<?>) obj).isEmpty();
		}
		if (obj instanceof Map) {
			return ((Map<?, ?>) obj).isEmpty();
		}
		if(obj instanceof String){
			return (obj == null || "".equals(obj));	
		}
		//else false
		return false;
	}

	public static void main(String[] args) {
		System.out.println(requireNonNull(""));
	}
}
