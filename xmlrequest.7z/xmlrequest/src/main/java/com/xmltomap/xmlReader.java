package com.xmltomap;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class xmlReader {
	public List<Map<String,String>> readFromXML(InputStream is) throws XMLStreamException {
		XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		XMLStreamReader reader = null;
		try {
			reader = inputFactory.createXMLStreamReader(is);
			return readDocument(reader);
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
	}
	public List<Map<String,String>> readFromXML(String xml) throws XMLStreamException {
		XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		XMLStreamReader reader = null;
		try {
			reader = inputFactory.createXMLStreamReader(new ByteArrayInputStream(xml.getBytes()));
			return readDocument(reader);
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
	}

	private List<Map<String, String>> readDocument(XMLStreamReader reader) throws XMLStreamException {
		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.START_ELEMENT:
				String elementName = reader.getLocalName();
				if (elementName.equals("Response"))    
					return readResponse(reader);
				break;
			case XMLStreamReader.END_ELEMENT:
				break;
			}
		}
		throw new XMLStreamException("Premature end of file");
	}

	private List<Map<String, String>> readResponse(XMLStreamReader reader) throws XMLStreamException {
		List<Map<String,String>> ResponseElement = new ArrayList<>();

		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.START_ELEMENT:
				String elementName = reader.getLocalName();
				if (elementName.equals("ResponseElement")) {
					ResponseElement.add(readResponseElement(reader)); 
				} else {
					readResponseElement(reader);
				}
				break;       
			case XMLStreamReader.END_ELEMENT:
				System.out.println("END_ELEMENT  ::: "+ResponseElement);
				return ResponseElement;
			}
		}
		throw new XMLStreamException("Premature end of file");
	}

	private Map<String, String> readResponseElement(XMLStreamReader reader) throws XMLStreamException {
		Map<String,String> ResponseElement=new HashMap<String,String>();
		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.START_ELEMENT:
				String elementName = reader.getLocalName();
				ResponseElement.put(elementName,readCharacters(reader));
				break;
			case XMLStreamReader.END_ELEMENT:
				return ResponseElement;
			}
		}
		throw new XMLStreamException("Premature end of file");
	}
	private String readCharacters(XMLStreamReader reader) throws XMLStreamException {
		StringBuilder result = new StringBuilder();
		while (reader.hasNext()) {
			int eventType = reader.next();
			switch (eventType) {
			case XMLStreamReader.CHARACTERS:
			case XMLStreamReader.CDATA:
				result.append(reader.getText());
				break;
			case XMLStreamReader.END_ELEMENT:
				return result.toString();
			}
		}
		throw new XMLStreamException("Premature end of file");
	}
}
