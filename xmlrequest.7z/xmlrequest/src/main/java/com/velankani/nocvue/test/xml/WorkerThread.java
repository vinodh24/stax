package com.velankani.nocvue.test.xml;

import java.util.Map;

public class WorkerThread implements Runnable {  
    private  Map<String, String> params;  
    public WorkerThread( Map<String, String> params){  
        this.params=params;  
    }  
     public void run() { 
    	 System.out.println(Thread.currentThread().getName()+" (Start) message = "+params);  
    	 TestMarshall tm=new TestMarshall();
    	 try {
			tm.jaxbObjectToXML(params);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println(Thread.currentThread().getName()+" (End)");//prints thread name  
    }  
   
}  