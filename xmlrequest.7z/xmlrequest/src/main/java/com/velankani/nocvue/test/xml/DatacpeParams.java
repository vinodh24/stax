package com.velankani.nocvue.test.xml;

import java.util.HashMap;
import java.util.Map;

/** This class can make as the bean and will keep in the xml  and will maintain all the maps in the xml like parenttype, handletype, filter condition & mandatory params */

/**
 * This class is related to get the relavent mandatory params for the data cpe
 * connection
 */

public class DatacpeParams {

	public static String Filter_Condition = "Filter_Condition";
	Map<String, String> ParentType = new HashMap<String, String>();
	Map<String, String> handleType = new HashMap<String, String>();
	Map<String, String> replaceXMlName = new HashMap<String, String>();
	Map<String, String> replaceXMlName1 = new HashMap<String, String>();
	Map<String, String> replaceXMlName2 = new HashMap<String, String>();
	Map<String, String> replaceXMlName3 = new HashMap<String, String>();

	DatacpeParams() {
		ParentType.put("Parent_Type", "Device");
		handleType.put("Handle_Type", "DynOmciCpeConnection");
		replaceXMlName.put("handleId", "Handle_Id");
		replaceXMlName1.put("parentId", "Parent_Id");
		replaceXMlName2.put("shelfNumber", "shelfId=shelfNumber");
		replaceXMlName2.put("cardNumber", "cardId=cardNumber");
		replaceXMlName3.put("portNumber", "tpIndex");
		replaceXMlName3.put("shelfNumber", "phyShelfId");
		replaceXMlName3.put("cardNumber", "phySlotId");
		replaceXMlName3.put("portNumber", "gponOltId");
	}

	public Map<String, String> getParentTypeParams() {
		return ParentType;
	}

	public Map<String, String> getHandleTypeParams() {
		return handleType;
	}

	public Map<String, String> getHandleIdsReplaceParams() {
		return replaceXMlName;
	}

	public Map<String, String> getParentIdsReplaceParams() {
		return replaceXMlName1;
	}

	public Map<String, String> getFilterConditionReplaceParams() {
		return replaceXMlName2;
	}

	public Map<String, String> getReplaceParams() {
		return replaceXMlName3;

	}

}
