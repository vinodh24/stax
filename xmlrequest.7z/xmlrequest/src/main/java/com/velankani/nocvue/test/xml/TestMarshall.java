/**
 * 
 */
package com.velankani.nocvue.test.xml;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.velankani.nocvue.dzone.xml.request.Attribute;
import com.velankani.nocvue.dzone.xml.request.OSS;
import com.velankani.nocvue.dzone.xml.request.Request;
import com.velankani.nocvue.dzone.xml.request.RequestElement;

public class TestMarshall {
	public static void main(String[] args) throws Exception {
		TestMarshall testMarshall = new TestMarshall();
		ExecutorService service = null;
		Set<Callable<Map<String, List<Map<String, String>>>>> callable = null;
		// Lets assume it will params from the GUI
		Map<String, String> params = new HashMap<String, String>();
		params.put("portNumber", "2");
		params.put("shelfNumber", "3");
		params.put("cardNumber", "1");
		params.put("portNumber", "5");
		params.put("parentId", "1000234");
		params.put("handleId", "1000224");

		service = Executors.newFixedThreadPool(1);
		for (int i = 0; i < 1; i++) {
			Runnable worker = new WorkerThread(params);
			service.execute(worker);// calling execute method of ExecutorService
		}
		service.shutdown();
		while (!service.isTerminated()) {
		}
		testMarshall.jaxbObjectToXML(params);
		//System.out.print("response:::");
		//System.out.println(System.currentTimeMillis() - currenttime);

	}

	public void jaxbObjectToXML(Map<String, String> params) throws Exception {
		try {
			// lets assume it as gpon_hsi for the add service and we have two
			// steps like
			// 1) create a data bridge
			// 2) create a cpe connection

			// we will iterate and will generate the xmls from the pojo

			// here in below i did sample request only for the step create a cpe
			// connection xml

			OSS oss = getOss(params);
			//System.out.println(oss.toString()+":::::soo");
			Request request = getRequest(params);
			RequestElement requestElement = getRequestElement(params);
			oss.setRequest(request);
			oss.setRequestElement(requestElement);

			JAXBContext jaxbContext = JAXBContext.newInstance(OSS.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
					Boolean.TRUE);
			StringWriter stringWriter = new StringWriter();
		   // File file = new File("samplerequest.xml");
			jaxbMarshaller.marshal(oss, stringWriter);
		      System.out.println(stringWriter.toString());
			 // Unmarshaller unmarshaller=jaxbContext.createUnmarshaller(OSS.class);
			  try{
				  
           
				  Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				  final SAXParserFactory sax = SAXParserFactory.newInstance();
				  sax.setNamespaceAware(false);
				  final XMLReader reader = sax.newSAXParser().getXMLReader();
				  //final Source er = new SAXSource(reader, new InputSource(new FileReader("D:\\Programs\\Examples\\stax\\src\\main\\resources\\test.xml")));
				  final Source er = new SAXSource(reader, new InputSource(new ByteArrayInputStream(stringWriter.toString().getBytes())));
		        
				  OSS oss1 = (OSS) unmarshaller.unmarshal(er);
				  System.out.println(oss1);
			 // System.out.println("oss1"+unmarshaller.unmarshal(new ByteArrayInputStream(stringWriter.toString().getBytes())));
			  }catch(Exception e){
				 e.printStackTrace(); 
			  }
			 
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}

	// xmlns related info ( common to all)
	public OSS getOss(Map<String, String> params) {
		OSS oss = new OSS();
		oss.setXmlns("http://www.zhone.com/OSSXML");
		oss.setXmlnsXsi("http://www.w3.org/2001/XMLSchema-instance");
		oss.setXsiSchemaLocation("http://www.zhone.com/OSSXML ossxml.xsd");
		return oss;

	}

	// Create the Request Object (create the request object based on the
	// required request like add, delete, list, get)
	public Request getRequest(Map<String, String> params) {
		Request request = new Request();
		request.setRequestType("add");
		request.setRequestMode("offline");
		request.setSessionID("1234512345");
		request.setOperName("velankani");
		request.setVersion("2.4");
		return request;
	}

	// Create the RequestElement Object which contains the elements like

	public RequestElement getRequestElement(Map<String, String> params)
			throws Exception {
		RequestElement requestElement = new RequestElement();

		List<Attribute> attributes = new ArrayList<Attribute>();
		Attribute attribute = new Attribute();

		/** Replace ParentType Params Start **/

		DatacpeParams datacpeParams = new DatacpeParams();

		Map<String, String> ParentTypeParams = datacpeParams
				.getParentTypeParams();
		if (ParentTypeParams != null && !ParentTypeParams.isEmpty()) {
			for (Entry<String, String> data : ParentTypeParams.entrySet()) {
				attribute = new Attribute();
				attribute.setName(data.getKey());
				attribute.setValue(data.getValue());
				attributes.add(attribute);
			}

			Map<String, String> parentIdParams = datacpeParams
					.getParentIdsReplaceParams();

			for (Entry<String, String> data : parentIdParams.entrySet()) {
				if (params.containsKey(data.getKey())) {
					attribute = new Attribute();
					attribute.setName(data.getValue());
					attribute.setValue(params.get(data.getKey()));
					attributes.add(attribute);
				} else {
					throw new Exception(data.getKey()
							+ " not available in the required params");
				}
			}
		}

		/** Replace ParentType Params End **/

		/** Replace handleTypeParams Params Start **/

		Map<String, String> handleTypeParams = datacpeParams
				.getHandleTypeParams();
		if (handleTypeParams != null && !handleTypeParams.isEmpty()) {
			for (Entry<String, String> data : handleTypeParams.entrySet()) {
				attribute = new Attribute();
				attribute.setName(data.getKey());
				attribute.setValue(data.getValue());
				attributes.add(attribute);
			}

			Map<String, String> handleIdParams = datacpeParams
					.getHandleIdsReplaceParams();

			for (Entry<String, String> data : handleIdParams.entrySet()) {
				if (params.containsKey(data.getKey())) {
					attribute = new Attribute();
					attribute.setName(data.getValue());
					attribute.setValue(params.get(data.getKey()));
					attributes.add(attribute);
				} else {
					throw new Exception(data.getKey()
							+ " not available in the required params");
				}
			}
		}

		/** Replace handleTypeParams Params End **/

		/** Replace FilterCondition Params Start **/

		Map<String, String> filterConditionParams = datacpeParams
				.getFilterConditionReplaceParams();

		if (filterConditionParams != null && !filterConditionParams.isEmpty()) {
			for (Entry<String, String> data : filterConditionParams.entrySet()) {
				if (params.containsKey(data.getKey())) {
					attribute = new Attribute();
					attribute.setName(DatacpeParams.Filter_Condition);
					attribute.setValue(data.getValue().replaceAll(
							data.getKey(), params.get(data.getKey())));
					attributes.add(attribute);
				} else {
					throw new Exception(data.getKey()
							+ " not available in the required params");
				}
			}
		}

		/** Replace FilterCondition Params End **/

		/** Replace Mandatory Params Start **/
		Map<String, String> mandatoryParams = datacpeParams.getReplaceParams();

		if (mandatoryParams != null && !mandatoryParams.isEmpty()) {
			for (Entry<String, String> data : mandatoryParams.entrySet()) {
				if (params.containsKey(data.getKey())) {
					attribute = new Attribute();
					attribute.setName(data.getValue());
					attribute.setValue(params.get(data.getKey()));
					attributes.add(attribute);
				} else {
					throw new Exception(data.getKey()
							+ " not available in the required params");
				}
			}
		}
		/** Replace Mandatory Params End **/

		requestElement.setAttribute(attributes);
		return requestElement;
	}

}
