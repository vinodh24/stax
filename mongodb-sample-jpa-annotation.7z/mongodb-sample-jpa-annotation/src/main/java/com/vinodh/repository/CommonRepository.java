package com.vinodh.repository;

import com.vinodh.model.Common;

public interface CommonRepository extends GenericDAO<Common>{

}
