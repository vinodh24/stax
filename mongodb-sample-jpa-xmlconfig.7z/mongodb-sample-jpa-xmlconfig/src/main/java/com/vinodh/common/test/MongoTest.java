package com.vinodh.common.test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.vinodh.model.Common;
import com.vinodh.service.CurdService;

public class MongoTest {

	public static void main(String args[]) {

		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("mongodb-context.xml");
		CurdService curdOperation = (CurdService) context.getBean("DaoOperations");
		System.out.println("mongoOps::::::::" + curdOperation);
		Common common = new Common();
		common.setId("vinodh");
		common.setPortName("vinodh prot name");
		common.setSubscriberId("vinodh12345");
		common.setTechnology("microservices");
		System.out.println("common:::::::" + common);
		try {
			curdOperation.save(common);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
