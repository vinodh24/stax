package com.vinodh.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.vinodh.model.Common;
import com.vinodh.repository.CommonRepository;
public class CurdService {
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private CommonRepository commonRepository;
	
	public void save(Common Common) {
		System.out.println(commonRepository+"   Common   :::"+Common);
		commonRepository.save(Common);
	}

}
